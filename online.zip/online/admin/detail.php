<?php
session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './view/navbar.php';

    $sql2 = "select * from akun_online_daftar_nama where id = " . clear($_GET["id"]);

    $result2 = mysqli_query($link, $sql2);
    ?>
    <body>
        <script>
            function windowConfirm() {
                var choice = confirm("Apakah anda yakin ingin menghapus data id = <?php echo clear($_GET["id"]); ?>?");
                if (choice == true) {
                    window.location = 'controller/hapusData.php?id=<?php echo clear($_GET["id"]); ?>';
                }
            }
        </script>
        <div class="container" style="margin-top: 70px; vertical-align: middle">
            <?php
            if (mysqli_num_rows($result2) > 0) {
                while ($row = mysqli_fetch_assoc($result2)) {
                    ?>
                    <div class="row">
                        <div class="container" style="width: 50%">
                            NIM <input type="text" disabled="" class="w3-right" style="width: 75%;" value="<?php echo $row["nim"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Nama Depan <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["first_name"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Nama Belakang <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["last_name"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Nama Lengkap <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["nama"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Fakultas <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["fakultas"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Jenjang <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["jenjang"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Tanggal Lahir <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["tgl_lahir"] . "/" . $row["bln_lahir"] . "/" . $row["thn_lahir"] ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Jenis Kelamin <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php
                            if ($row["gender"] == "M") {
                                echo "PRIA";
                            } else {
                                echo 'WANITA';
                            }
                            ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Email <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["email"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            No. HP <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["hp"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            No. WA <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["wa"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Kebangsaan <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["nat_country"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 10px">
                        <div class="container" style="width: 50%">
                            Bahasa Asli <input type="text" disabled="" class="w3-right" style="width: 75%" value="<?php echo $row["nat_language"]; ?>">
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
        <div class="container w3-center" style="margin-top: 15px; margin-bottom: 50px">
            <a style="text-decoration: none; margin-right: 25px" href="ubahData.php?id=<?php echo clear($_GET["id"]); ?>">
                <button class="w3-button w3-round-large w3-yellow w3-hover-orange">
                    Ubah Data
                </button>
            </a>
            <a style="text-decoration: none; margin-right: 25px" href="#" onclick="windowConfirm()">
                <button class="w3-button w3-round-large w3-yellow w3-hover-orange">
                    Hapus Data
                </button>
            </a>
            <a style="text-decoration: none; margin-right: 25px" href="./">
                <button class="w3-button w3-round-large w3-yellow w3-hover-orange">
                    Kembali
                </button>
            </a>
        </div>
    </body>
    <?php
}