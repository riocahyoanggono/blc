<?php

header("location: ../");