<?php

function getGlitch($link) {
    $sql = "select * from akun_online where confirmation = 1 order by queue_confirm";
    $result = mysqli_query($link, $sql);

    $array = $problems = array();

    while ($row = mysqli_fetch_assoc($result)) {
        array_push($array, $row["queue_confirm"]);
    }

    $max_array = count($array);
    $j = 1;
    for ($p = 0; $p < $max_array; $p++) {
        if ($j != $array[$p]) {
            for ($x = $j; $x < $array[$p]; $x++) {
                array_push($problems, $x);
                $j++;
            }
        }
        $j++;
    }
    return $problems;
}