<!DOCTYPE html>
<?php
session_start();

function clear($data) {
    return htmlspecialchars(stripcslashes(trim($data)));
}

include '../../model/db_connection.php';

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    if (!empty($_GET["id"])) {
        $sql = "update akun_online set close = 0 where id = " . clear($_GET["id"]);
        mysqli_query($link, $sql);
        echo "<script> window.location = '../detail.php?id=".  clear($_GET["id"])."';</script>";
    }
    echo "<script> window.location = '../';</script>";
}
