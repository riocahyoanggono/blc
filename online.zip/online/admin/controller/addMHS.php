<?php

session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    include '../../controller/func_enc_dec.php';

    if (empty($_POST["nim"])) {
        ?>
        <script>
            window.location = "../";
        </script>
        <?php

    } else {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $nama = clear($_POST["nama"]);
            $nim = encode(clear($_POST["nim"]));
            $fakultas = clear($_POST["fakultas"]);
            $password = encode(clear($_POST["password"]));

            $sql = "select * from akun_online where user = '$nim'";
            $result = mysqli_query($link, $sql);
            if (mysqli_num_rows($result) == 0) {

                $sql2 = "insert INTO akun_online VALUES ('','$nim','$password',0,0,0,'','',0)";
                mysqli_query($link, $sql2);
                $sql4 = "select * from akun_online where user = '$nim'";
                $result4 = mysqli_query($link, $sql4);
                if (mysqli_num_rows($result4) > 0) {
                    while ($row = mysqli_fetch_assoc($result4)) {
                        $sql3 = "insert INTO akun_online_daftar_nama values "
                                . "('" . $row["id"] . "', "
                                . "'" . strtoupper($nama) . "',"
                                . "'',"
                                . "'',"
                                . "'" . decode($nim) . "',"
                                . "'" . $fakultas . "',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'',"
                                . "'')";
                        mysqli_query($link, $sql3);
                    }
                    echo "<script>window.alert('Sukses')</script>";
                    echo '<script>window.location = "../";</script>';
                }
            } else {
                echo "<script>window.alert('NIM sudah ada.')</script>";
                echo '<script>window.location = "../";</script>';
            }
        } else {
            echo '<script>window.location = "../";</script>';
        }
    }
}