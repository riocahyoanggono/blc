<?php

session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $temp = explode("-", clear($_POST["tgl"]));
        $tgl = $temp["2"] . "/" . $temp["1"] . "/" . $temp["0"];
        $waktu = clear($_POST["waktu"]);
        $sql = "select * from tanggal_tes where tgl = '$tgl' and waktu = '$waktu'";
        $result = mysqli_query($link, $sql);
        if (mysqli_num_rows($result) == 0) {
            $sql2 = "insert into tanggal_tes values ('','$tgl','$waktu')";
            mysqli_query($link, $sql2);
            ?>
            <script>
                window.alert("SUKSES!");
                window.location = "../addJadwal.php";
            </script>
            <?php

        }
    }
}