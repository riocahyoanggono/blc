<?php

session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    $sql = "select * from counter where id = 4";
    $result = mysqli_query($link, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        if (intval($row["count"]) !== 0) {
            $sql2 = "update counter set count = 0 where id = 4";
            mysqli_query($link, $sql2);
            echo "<script> window.location = '../setting.php';</script>";
        } else {
            $sql2 = "select max(queue_confirm) as q from akun_online";
            $result2 = mysqli_query($link, $sql2);
            while ($row2 = mysqli_fetch_assoc($result2)) {
                $sql3 = "update counter set count = '" . $row2["q"] . "' where id = 4";
                mysqli_query($link, $sql3);
                echo "<script> window.location = '../setting.php';</script>";
            }
        }
    }
}