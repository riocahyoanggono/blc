<?php

session_start();
include '../../model/db_connection.php';
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    $sql = "TRUNCATE table akun_online_daftar_nama";
    mysqli_query($link, $sql);
    $sql2 = "select id from akun_online where not id = 1";
    $result2 = mysqli_query($link, $sql2);
    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
            $sql3 = "delete from akun_online where id = " . $row["id"];
            mysqli_query($link, $sql3);
        }
    }
    $sql4 = "update counter set count = 0 where id = 4";
    mysqli_query($link, $sql4);
    echo "<script>window.alert('Tabel Sukses Dikosongi!!!')</script>";
    echo "<script> window.location = '../';</script>";
}