<?php
session_start();
function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
include '../../model/db_connection.php';

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    if(!empty($_GET["id"])) {
        $sql = "delete from akun_online_daftar_nama where id = ".clear($_GET["id"]);
        mysqli_query($link, $sql);
        $sql2 = "delete from akun_online where id = ".clear($_GET["id"]);
        mysqli_query($link, $sql2);
        echo "<script>alert('Data Terhapus!'); history-go(-1);</script>";
        echo "<script> window.location = '../';</script>";
    }
    echo "<script> window.location = '../';</script>";
}