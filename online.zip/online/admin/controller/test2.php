<?php

function encode($s) {
    $re = str_split($s);
    $re3 = [];
    $encrypted = [];
    for ($i = 0; $i < count($re); $i++) {
        $re3[$i] = intval(ord($re[$i]));
    }
    $f_key = $re3[0];
    $encrypted[0] = pow($f_key, 2);
    for ($i = 0; $i < count($re); $i++) {
        $encrypted[$i + 1] = pow($f_key + $re3[$i], 2);
    }
    return implode(" ", $encrypted);
}

function decode($s) {
    $re = explode(" ", $s);
    $f_key = sqrt($re[0]);
    for ($i = 1; $i < count($re); $i++) {

        $decrypted[$i] = chr(sqrt($re[$i]) - $f_key);
    }
    return implode("", $decrypted);
}
//echo encode("Dependante");
echo encode(openssl_encrypt(encode("Dependante"), "AES-256-CTR", "I93091isp3idoo4"));