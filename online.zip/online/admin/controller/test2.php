<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$name = trim("Rio Cahyo Anggono Saksomo Kalian Suara S");
$name2 = explode(" ", $name);//dipisah perkata
$name3 = str_split($name);//dipisah perhuruf
$c = 0;//penghitung jumlah yang disingkat
while (count($name3) > 30) {
    $temp = str_split($name2[count($name2) - (1 + $c)]);
    $name2[count($name2) - (1 + $c)] = $temp[0];
    $name = implode(" ", $name2);
    $name3 = str_split($name);
    $c++;
}