<?php

session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    include '../../controller/func_enc_dec.php';
    $user = encode('1234');
    $pass = encode('1234');
    $sql = "insert INTO akun_online VALUES ('','$user','$pass',0,0,0,'','',0)";
    mysqli_query($link, $sql);

    $sql2 = "select * from akun_online where user = '$user'";
    $result2 = mysqli_query($link, $sql2);
    while ($row = mysqli_fetch_assoc($link, $result2)) {
        $sql3 = "insert INTO akun_online_daftar_nama values "
                . "('" . $row["id"] . "', "
                . "'DUMMY',"
                . "'',"
                . "'',"
                . "'1234',"
                . "'FH',"
                . "'',"
                . "'',"
                . "'',"
                . "'',"
                . "'',"
                . "'08123456789',"
                . "'08123456789',"
                . "'',"
                . "'',"
                . "'',"
                . "'',"
                . "'')";
        mysqli_query($link, $sql3);
    }
    echo "<script>window.alert('DUMMY ADDED!')</script>";
    echo '<script>window.location = "../";</script>';
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

