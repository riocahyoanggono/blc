<?php

include '../../model/db_connection.php';
include '../lib/PHPExcel-1.8/Classes/PHPExcel.php';
include './glitch_counter.php';

function clear($data) {
    return trim(stripcslashes(htmlspecialchars($data)));
}

$sql20 = "select * from counter where id = 4";
$result20 = mysqli_query($link, $sql20);
while ($row = mysqli_fetch_assoc($result20)) {
    $topAfter = $row["count"];
}
$sql21 = "select * from online_settings";
$result21 = mysqli_query($link, $sql21);

while ($row = mysqli_fetch_assoc($result21)) {
    $jumlah_peserta = intval($row["jumlah_peserta"]);
    $jumlah_proctor = intval($row["jumlah_proctor"]);
    $jumlah_sesi = intval($row["jumlah_sesi"]);
    $peserta_proctor = intval($row["peserta_proctor"]);
    $tgl_tes = $row["tgl_tes"];
}

$glitch = getGlitch($link);

error_reporting(E_ALL);

ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
define('EOL', (PHP_SAPI == 'cli') ? PHP_EOL : '<br />');
date_default_timezone_set("Asia/Jakarta");

if (clear($_GET["download"]) === "proctor") {
    $objPHPExcel = new PHPExcel();
    $proctor = intval(clear($_GET["no"]));
    $sesi = intval(clear($_GET["sesi"]));
    $top = $peserta_proctor * ($proctor + $jumlah_proctor * $sesi) + 1;
    $limit = $peserta_proctor * (($proctor + 1) + $jumlah_proctor * $sesi);
    if ($proctor === 6 && $sesi === 1) {
        $limit*=10;
    }

    $sql = "select * FROM akun_online inner join akun_online_daftar_nama on akun_online_daftar_nama.id = akun_online.id where akun_online.queue_confirm between $top and $limit and akun_online.queue_confirm > $topAfter order by akun_online_daftar_nama.nama asc";
    $result = mysqli_query($link, $sql);

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', "Urutan Konfirmasi")
            ->setCellValue('B1', "Nama")
            ->setCellValue('C1', "Nama Belakang")
            ->setCellValue('D1', "No. Hp")
            ->setCellValue('E1', "No. WA");

    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {

        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $row["queue_confirm"])
                ->setCellValue('B' . $counter, $row["nama"])
                ->setCellValue('C' . $counter, $row["last_name"])
                ->setCellValue('D' . $counter, $row["hp"])
                ->setCellValue('E' . $counter, $row["wa"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Proctor " . ($proctor + 1) . " Sesi " . ($sesi + 1));

    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="'.$tgl_tes.' Proctor ' . ($proctor + 1) . " Sesi " . ($sesi + 1) . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
}
/*
  //elseif (clear($_GET["download"]) === "upload") {
  //    $sql = "select * FROM akun_online_daftar_nama "
  //            . "inner join akun_online "
  //            . "on akun_online_daftar_nama.id = akun_online.id "
  //            . "where akun_online.confirmation = 1 "
  //            . "and not akun_online.id = 1 "
  //            . "order by queue_confirm asc";
  //
  //    $result = mysqli_query($link, $sql);
  //
  //    error_reporting(E_ALL);
  //
  //    ini_set('display_errors', TRUE);
  //    ini_set('display_startup_errors', TRUE);
  //
  //    $objPHPExcel = new PHPExcel();
  //    date_default_timezone_set("Asia/Jakarta");
  //
  //    $objPHPExcel->getProperties()
  //            ->setCreator("BLC UB")
  //            ->setLastModifiedBy("BLC UB")
  //            ->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"))
  //            ->setSubject("TOEFL ITP Online BLC " . date("d-m-Y"))
  //            ->setDescription("TOEFL ITP Online BLC " . date("d-m-Y"))
  //            ->setKeywords("toefl rutin online blc")
  //            ->setCategory("rutin");
  //
  //    $objPHPExcel->setActiveSheetIndex(0)
  //            ->setCellValue('A1', 'No')
  //            ->setCellValue('B1', 'StudentUniqueID')
  //            ->setCellValue('C1', 'StudentFamilyName')
  //            ->setCellValue('D1', 'StudentGivenName')
  //            ->setCellValue('E1', 'NameinLocalLanguage')
  //            ->setCellValue('F1', 'ResidenceCountryCode')
  //            ->setCellValue('G1', 'DOBMonth')
  //            ->setCellValue('H1', 'DOBDay')
  //            ->setCellValue('I1', 'DOBYear')
  //            ->setCellValue('J1', 'Gender')
  //            ->setCellValue('K1', 'NativeCountryCode')
  //            ->setCellValue('L1', 'NativeLanguageCode')
  //            ->setCellValue('M1', 'L_LN')
  //            ->setCellValue('N1', 'L_FN')
  //            ->setCellValue('O1', 'L_N')
  //            ->setCellValue('P1', 'F_SPACE')
  //            ->setCellValue('Q1', 'M_LN_N(LN)')
  //            ->setCellValue('R1', 'Proctor')
  //            ->setCellValue('S1', 'Session');
  //    $counter = 2;
  //    while ($row = mysqli_fetch_assoc($result)) {
  //        $sesi = ceil(intval($row["queue_confirm"]) * $jumlah_sesi / $jumlah_peserta);
  //        $proctor = ceil(intval($row["queue_confirm"]) / $peserta_proctor) - $jumlah_proctor * ($sesi - 1);
  //        $objPHPExcel->setActiveSheetIndex(0)
  //                ->setCellValue('A' . $counter, $counter - 1)
  //                ->setCellValue('B' . $counter, $row["nim"])
  //                ->setCellValue('C' . $counter, $row["last_name"])
  //                ->setCellValue('D' . $counter, $row["first_name"])
  //                ->setCellValue('E' . $counter, $row["nama"])
  //                ->setCellValue('F' . $counter, "IDN")
  //                ->setCellValue('G' . $counter, date("M", mktime(0,0,0,intval($row["bln_lahir"]),1,2020)))
  //                ->setCellValue('H' . $counter, $row["tgl_lahir"])
  //                ->setCellValue('I' . $counter, $row["thn_lahir"])
  //                ->setCellValue('J' . $counter, $row["gender"])
  //                ->setCellValue('K' . $counter, $row["country_code"])
  //                ->setCellValue('L' . $counter, $row["language_code"])
  //                ->setCellValue('M' . $counter, '=len(C' . $counter . ')')
  //                ->setCellValue('N' . $counter, '=len(D' . $counter . ')')
  //                ->setCellValue('O' . $counter, '=len(E' . $counter . ')')
  //                ->setCellValue('P' . $counter, '=FIND(" ";C' . $counter . ';1)')
  //                ->setCellValue('Q' . $counter, '=IF(C' . $counter . '=RIGHT(E' . $counter . ';LEN(C' . $counter . '));"TRUE";"FALSE")')
  //                ->setCellValue('R' . $counter, $proctor)
  //                ->setCellValue('S' . $counter, $sesi);
  //        $counter++;
  //    }
  //    $objPHPExcel->getActiveSheet()->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"));
  //    $objPHPExcel->setActiveSheetIndex(0);
  //
  //    header('Content-Type: application/vnd.ms-excel');
  //    header('Content-Disposition: attachment;filename="TOEFL ITP Online BLC ' . date("d-m-Y") . '.xls"');
  //    header('Cache-Control: max-age=0');
  //    header('Cache-Control: max-age=1');
  //
  //
  //    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
  //    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
  //    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
  //    header('Pragma: public'); // HTTP/1.0
  //
  //    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
  //    $objWriter->save('php://output');
  //    exit;
  ////}
 */ elseif (clear($_GET["download"]) === "upload") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online "
            . "on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 1 "
            . "and not akun_online.id = 1 "
            . "order by queue_confirm asc";

    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setSubject("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setDescription("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No')
            ->setCellValue('B1', 'StudentUniqueID')
            ->setCellValue('C1', 'StudentFamilyName')
            ->setCellValue('D1', 'StudentGivenName')
            ->setCellValue('E1', 'NameinLocalLanguage')
            ->setCellValue('F1', 'ResidenceCountryCode')
            ->setCellValue('G1', 'DOBMonth')
            ->setCellValue('H1', 'DOBDay')
            ->setCellValue('I1', 'DOBYear')
            ->setCellValue('J1', 'Gender')
            ->setCellValue('K1', 'NativeCountryCode')
            ->setCellValue('L1', 'NativeLanguageCode')
            ->setCellValue('M1', 'REAL_NAME')
            ->setCellValue('N1', 'FAKULTAS')
            ->setCellValue('O1', 'L_LN')
            ->setCellValue('P1', 'L_FN')
            ->setCellValue('Q1', 'L_N')
            ->setCellValue('R1', 'F_SPACE_LN')
            ->setCellValue('S1', 'F_DOT_LN')
            ->setCellValue('T1', 'F_DOT_FN')
            ->setCellValue('U1', 'F_DOT_N')
            ->setCellValue('V1', 'M_LN_N(LN)')
            ->setCellValue('W1', 'Proctor')
            ->setCellValue('X1', 'Session')
            ->setCellValue('Y1', 'ID_SYSTEM');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $real_name = $row["nama"];
        $name = trim($row["nama"]);
        $name2 = explode(" ", $name); //dipisah perkata
        $name3 = str_split($name); //dipisah perhuruf
        $c = 0; //penghitung jumlah yang disingkat
        while (count($name3) > 30) {
            $temp = str_split($name2[count($name2) - (1 + $c)]);
            $name2[count($name2) - (1 + $c)] = $temp[0];
            $name = implode(" ", $name2);
            $name3 = str_split($name);
            $c++;
        }
        $sesi = ceil(intval($row["queue_confirm"]) / ($jumlah_peserta / $jumlah_sesi));
        $proctor = ceil(intval($row["queue_confirm"]) / $peserta_proctor) - $jumlah_proctor * ($sesi - 1);
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["nim"])
                ->setCellValue('C' . $counter, $row["last_name"])
                ->setCellValue('D' . $counter, $row["first_name"])
                ->setCellValue('E' . $counter, $name)
                ->setCellValue('F' . $counter, "IDN")
                ->setCellValue('G' . $counter, date("M", mktime(0, 0, 0, intval($row["bln_lahir"]), 1, 2020)))
                ->setCellValue('H' . $counter, $row["tgl_lahir"])
                ->setCellValue('I' . $counter, $row["thn_lahir"])
                ->setCellValue('J' . $counter, $row["gender"])
                ->setCellValue('K' . $counter, $row["country_code"])
                ->setCellValue('L' . $counter, $row["language_code"])
                ->setCellValue('M' . $counter, $real_name)
                ->setCellValue('N' . $counter, $row["fakultas"])
                ->setCellValue('O' . $counter, '=len(C' . $counter . ')')
                ->setCellValue('P' . $counter, '=len(D' . $counter . ')')
                ->setCellValue('Q' . $counter, '=len(E' . $counter . ')')
                ->setCellValue('R' . $counter, '=FIND(" ";C' . $counter . ';1)')
                ->setCellValue('S' . $counter, '=FIND(".";C' . $counter . ';1)')
                ->setCellValue('T' . $counter, '=FIND(".";D' . $counter . ';1)')
                ->setCellValue('U' . $counter, '=FIND(".";E' . $counter . ';1)')
                ->setCellValue('V' . $counter, '=IF(C' . $counter . '=RIGHT(E' . $counter . ';LEN(C' . $counter . '));"TRUE";"FALSE")')
                ->setCellValue('W' . $counter, $proctor)
                ->setCellValue('X' . $counter, $sesi)
                ->setCellValue('Y' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("ETS Upload " . $tgl_tes);
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="TOEFL ITP Online BLC ' . $tgl_tes . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} elseif (clear($_GET["download"]) === "template") {

    $file = '../template/template_data.xls';

    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
} elseif (clear($_GET["download"]) === "all") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where not akun_online.id = 1 "
            . "order by akun_online.queue_confirm";
    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setSubject("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setDescription("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'Urutan Konfirmasi')
            ->setCellValue('C1', 'Waktu Update')
            ->setCellValue('D1', 'Waktu Konfirmasi')
            ->setCellValue('E1', 'NIM')
            ->setCellValue('F1', 'Nama')
            ->setCellValue('G1', 'Fakultas')
            ->setCellValue('H1', 'Jenjang')
            ->setCellValue('I1', 'Email')
            ->setCellValue('J1', 'No. HP')
            ->setCellValue('K1', 'No. WA')
            ->setCellValue('L1', 'Bulan Lahir')
            ->setCellValue('M1', 'Tanggal Lahir')
            ->setCellValue('N1', 'Tahun Lahir')
            ->setCellValue('O1', 'Jenis Kelamin')
            ->setCellValue('P1', 'Native Country')
            ->setCellValue('Q1', 'Native Language')
            ->setCellValue('R1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $time_update = str_replace("<br>", " ", $row["time_update"]);
        $time_confirmation = str_replace("<br>", " ", $row["time_confirmation"]);
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["queue_confirm"])
                ->setCellValue('C' . $counter, $time_update)
                ->setCellValue('D' . $counter, $time_confirmation)
                ->setCellValue('E' . $counter, $row["nim"])
                ->setCellValue('F' . $counter, $row["nama"])
                ->setCellValue('G' . $counter, $row["fakultas"])
                ->setCellValue('H' . $counter, $row["jenjang"])
                ->setCellValue('I' . $counter, $row["email"])
                ->setCellValue('J' . $counter, $row["hp"])
                ->setCellValue('K' . $counter, $row["wa"])
                ->setCellValue('L' . $counter, $row["bln_lahir"])
                ->setCellValue('M' . $counter, $row["tgl_lahir"])
                ->setCellValue('N' . $counter, $row["thn_lahir"])
                ->setCellValue('O' . $counter, $row["gender"])
                ->setCellValue('P' . $counter, $row["country_code"])
                ->setCellValue('Q' . $counter, $row["language_code"])
                ->setCellValue('R' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Rekap TOEFL ITP " . $tgl_tes);
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Rekap TOEFL ITP ' . $tgl_tes . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} elseif (clear($_GET["download"]) === "nc") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 0 "
            . "and akun_online.status = 1 "
            . "and akun_online.close != 1 "
            . "order by akun_online.id";

    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Belum Konfirmasi " . date("d-m-Y"))
            ->setSubject("Belum Konfirmasi " . date("d-m-Y"))
            ->setDescription("Belum Konfirmasi" . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'Waktu Update')
            ->setCellValue('C1', 'NIM')
            ->setCellValue('D1', 'Nama')
            ->setCellValue('E1', 'Fakultas')
            ->setCellValue('F1', 'Jenjang')
            ->setCellValue('G1', 'Email')
            ->setCellValue('H1', 'No. HP')
            ->setCellValue('I1', 'No. WA')
            ->setCellValue('J1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $time_update = str_replace("<br>", " ", $row["time_update"]);
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $time_update)
                ->setCellValue('C' . $counter, $row["nim"])
                ->setCellValue('D' . $counter, $row["nama"])
                ->setCellValue('E' . $counter, $row["fakultas"])
                ->setCellValue('F' . $counter, $row["jenjang"])
                ->setCellValue('G' . $counter, $row["email"])
                ->setCellValue('H' . $counter, $row["hp"])
                ->setCellValue('I' . $counter, $row["wa"])
                ->setCellValue('J' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Belum Konfirmasi " . $tgl_tes);
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Belum Konfirmasi ' . $tgl_tes . ' v' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} elseif (clear($_GET["download"] === "nu")) {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 0 "
            . "and akun_online.status = 0 "
            . "and akun_online.close = 0";
    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Tidak Update " . date("d-m-Y"))
            ->setSubject("Tidak Update " . date("d-m-Y"))
            ->setDescription("Tidak Update " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'NIM')
            ->setCellValue('C1', 'Nama')
            ->setCellValue('D1', 'Fakultas')
            ->setCellValue('E1', 'No. HP')
            ->setCellValue('F1', 'No. WA')
            ->setCellValue('G1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["nim"])
                ->setCellValue('C' . $counter, $row["nama"])
                ->setCellValue('D' . $counter, $row["fakultas"])
                ->setCellValue('E' . $counter, $row["hp"])
                ->setCellValue('F' . $counter, $row["wa"])
                ->setCellValue('G' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Tidak Update " . $tgl_tes);
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Tidak Update ' . $tgl_tes . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
}