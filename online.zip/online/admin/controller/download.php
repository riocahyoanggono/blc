<?php

include '../../model/db_connection.php';
include '../lib/PHPExcel-1.8/Classes/PHPExcel.php';
include './glitch_counter.php';

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$sql20 = "select * from counter where id = 4";
$result20 = mysqli_query($link, $sql20);
while ($row = mysqli_fetch_assoc($result20)) {
    $topAfter = $row["count"];
}

$glitch = getGlitch($link);

error_reporting(E_ALL);

ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

$objPHPExcel = new PHPExcel();
date_default_timezone_set("Asia/Jakarta");

if (clear($_GET["download"]) === "proctor") {
    if (intval(clear($_GET["no"])) < 8) {
        $proctor_no = intval(clear($_GET["no"]));
        $sesi = 1;
    } else {
        $proctor_no = intval(clear($_GET["no"]) - 7);
        $sesi = 2;
    }
    $top = $limit = 0;
//    if (clear($_GET["no"]) === "1") {
//        $top = 1;
//        $limit = 21;
    if (clear($_GET["no"]) === "1") {
        $top = 1;
        $limit = 30;
//    } elseif (clear($_GET["no"]) === "2") {
//        $top = 22;
//        $limit = 51;
    } elseif (clear($_GET["no"]) === "2") {
        $top = 31;
        $limit = 60;
//    } elseif (clear($_GET["no"]) === "3") {
//        $top = 52;
//        $limit = 52;
    } elseif (clear($_GET["no"]) === "3") {
        $top = 61;
        $limit = 90;
//    } elseif (clear($_GET["no"]) === "4") {
//        $top = 74;
//        $limit = 74;
    } elseif (clear($_GET["no"]) === "4") {
        $top = 91;
        $limit = 120;
    } elseif (clear($_GET["no"]) === "5") {
        $top = 121;
        $limit = 150;
    } elseif (clear($_GET["no"]) === "6") {
        $top = 151;
        $limit = 180;
    } elseif (clear($_GET["no"]) === "7") {
        $top = 181;
        $limit = 210;
    } elseif (clear($_GET["no"]) === "8") {
        $top = 211;
        $limit = 240;
    } elseif (clear($_GET["no"]) === "9") {
        $top = 241;
        $limit = 270;
    } elseif (clear($_GET["no"]) === "10") {
        $top = 271;
        $limit = 300;
    } elseif (clear($_GET["no"]) === "11") {
        $top = 301;
        $limit = 330;
    } elseif (clear($_GET["no"]) === "12") {
        $top = 331;
        $limit = 360;
    } elseif (clear($_GET["no"]) === "13") {
        $top = 361;
        $limit = 390;
    } elseif (clear($_GET["no"]) === "14") {
        $top = 391;
        $limit = 999;
    }

    $sql = "select * FROM akun_online inner join akun_online_daftar_nama on akun_online_daftar_nama.id = akun_online.id where akun_online.queue_confirm between $top and $limit and akun_online.queue_confirm > $topAfter order by akun_online_daftar_nama.nama asc";
    $result = mysqli_query($link, $sql);

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', "Urutan Konfirmasi")
            ->setCellValue('B1', "Nama")
            ->setCellValue('C1', "Nama Belakang")
            ->setCellValue('D1', "No. Hp")
            ->setCellValue('E1', "No. WA");

    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {

        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $row["queue_confirm"])
                ->setCellValue('B' . $counter, $row["nama"])
                ->setCellValue('C' . $counter, $row["last_name"])
                ->setCellValue('D' . $counter, $row["hp"])
                ->setCellValue('E' . $counter, $row["wa"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Proctor " . $proctor_no . " Sesi " . $sesi);

    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Proctor ' . $proctor_no . " Sesi " . $sesi . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} 
elseif (clear($_GET["download"]) === "upload") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online "
            . "on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 1 "
            . "and not akun_online.id = 1 "
            . "and akun_online.queue_confirm > $topAfter "
            . "order by queue_confirm asc";

    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setSubject("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setDescription("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No')
            ->setCellValue('B1', 'StudentUniqueID')
            ->setCellValue('C1', 'StudentFamilyName')
            ->setCellValue('D1', 'StudentGivenName')
            ->setCellValue('E1', 'NameinLocalLanguage')
            ->setCellValue('F1', 'ResidenceCountryCode')
            ->setCellValue('G1', 'DOBMonth')
            ->setCellValue('H1', 'DOBDay')
            ->setCellValue('I1', 'DOBYear')
            ->setCellValue('J1', 'Gender')
            ->setCellValue('K1', 'NativeCountryCode')
            ->setCellValue('L1', 'NativeLanguageCode')
            ->setCellValue('M1', 'L_LN')
            ->setCellValue('N1', 'L_FN')
            ->setCellValue('O1', 'L_N')
            ->setCellValue('P1', 'F_SPACE')
            ->setCellValue('Q1', 'M_LN_N(LN)')
            ->setCellValue('R1', 'Proctor')
            ->setCellValue('S1', 'Session');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        switch ($row["bln_lahir"]) {
            case "01":
                $bulan_lahir = "JAN";
                break;
            case "02":
                $bulan_lahir = "FEB";
                break;
            case "03":
                $bulan_lahir = "MAR";
                break;
            case "04":
                $bulan_lahir = "APR";
                break;
            case "05":
                $bulan_lahir = "MAY";
                break;
            case "06":
                $bulan_lahir = "JUN";
                break;
            case "07":
                $bulan_lahir = "JUL";
                break;
            case "08":
                $bulan_lahir = "AUG";
                break;
            case "09":
                $bulan_lahir = "SEP";
                break;
            case "10":
                $bulan_lahir = "OCT";
                break;
            case "11":
                $bulan_lahir = "NOV";
                break;
            case "12":
                $bulan_lahir = "DEC";
                break;
        }
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["nim"])
                ->setCellValue('C' . $counter, $row["last_name"])
                ->setCellValue('D' . $counter, $row["first_name"])
                ->setCellValue('E' . $counter, $row["nama"])
                ->setCellValue('F' . $counter, "IDN")
                ->setCellValue('G' . $counter, $bulan_lahir)
                ->setCellValue('H' . $counter, $row["tgl_lahir"])
                ->setCellValue('I' . $counter, $row["thn_lahir"])
                ->setCellValue('J' . $counter, $row["gender"])
                ->setCellValue('K' . $counter, $row["country_code"])
                ->setCellValue('L' . $counter, $row["language_code"])
                ->setCellValue('M' . $counter, '=len(C' . $counter . ')')
                ->setCellValue('N' . $counter, '=len(D' . $counter . ')')
                ->setCellValue('O' . $counter, '=len(E' . $counter . ')')
                ->setCellValue('P' . $counter, '=FIND(" ";C' . $counter . ';1)')
                ->setCellValue('Q' . $counter, '=IF(C' . $counter . '=RIGHT(E' . $counter . ';LEN(C' . $counter . '));"TRUE";"FALSE")')
                ->setCellValue('R' . $counter, '=IF(OR(' . $row["queue_confirm"] . '<31;AND(' . $row["queue_confirm"] . '>210;' . $row["queue_confirm"] . '<241));1;IF(OR(AND(' . $row["queue_confirm"] . '>30;' . $row["queue_confirm"] . '<61);AND(' . $row["queue_confirm"] . '>240;' . $row["queue_confirm"] . '<271));2;IF(OR(AND(' . $row["queue_confirm"] . '>60;' . $row["queue_confirm"] . '<91);AND(' . $row["queue_confirm"] . '>270;' . $row["queue_confirm"] . '<301));3;IF(OR(AND(' . $row["queue_confirm"] . '>90;' . $row["queue_confirm"] . '<121);AND(' . $row["queue_confirm"] . '>300;' . $row["queue_confirm"] . '<331));4;IF(OR(AND(' . $row["queue_confirm"] . '>120;' . $row["queue_confirm"] . '<151);AND(' . $row["queue_confirm"] . '>330;' . $row["queue_confirm"] . '<361));5;IF(OR(AND(' . $row["queue_confirm"] . '>150;' . $row["queue_confirm"] . '<181);AND(' . $row["queue_confirm"] . '>360;' . $row["queue_confirm"] . '<391));6;7))))))')
                ->setCellValue('S' . $counter, '=IF(' . $row["queue_confirm"] . '<211;1;2)');
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"));
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="TOEFL ITP Online BLC ' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');


    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} 
elseif (clear($_GET["download"]) === "upload_beta") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online "
            . "on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 1 "
            . "and not akun_online.id = 1 "
            . "and akun_online.queue_confirm > $topAfter "
            . "order by queue_confirm asc";

    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setSubject("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setDescription("TOEFL ITP Online BLC " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No')
            ->setCellValue('B1', 'StudentUniqueID')
            ->setCellValue('C1', 'StudentFamilyName')
            ->setCellValue('D1', 'StudentGivenName')
            ->setCellValue('E1', 'NameinLocalLanguage')
            ->setCellValue('F1', 'ResidenceCountryCode')
            ->setCellValue('G1', 'DOBMonth')
            ->setCellValue('H1', 'DOBDay')
            ->setCellValue('I1', 'DOBYear')
            ->setCellValue('J1', 'Gender')
            ->setCellValue('K1', 'NativeCountryCode')
            ->setCellValue('L1', 'NativeLanguageCode')
            ->setCellValue('M1', 'L_LN')
            ->setCellValue('N1', 'L_FN')
            ->setCellValue('O1', 'L_N')
            ->setCellValue('P1', 'F_SPACE')
            ->setCellValue('Q1', 'M_LN_N(LN)')
            ->setCellValue('R1', 'Proctor')
            ->setCellValue('S1', 'Session');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        switch ($row["bln_lahir"]) {
            case "01":
                $bulan_lahir = "JAN";
                break;
            case "02":
                $bulan_lahir = "FEB";
                break;
            case "03":
                $bulan_lahir = "MAR";
                break;
            case "04":
                $bulan_lahir = "APR";
                break;
            case "05":
                $bulan_lahir = "MAY";
                break;
            case "06":
                $bulan_lahir = "JUN";
                break;
            case "07":
                $bulan_lahir = "JUL";
                break;
            case "08":
                $bulan_lahir = "AUG";
                break;
            case "09":
                $bulan_lahir = "SEP";
                break;
            case "10":
                $bulan_lahir = "OCT";
                break;
            case "11":
                $bulan_lahir = "NOV";
                break;
            case "12":
                $bulan_lahir = "DEC";
                break;
        }
        $name = trim($row["nama"]);
        $name2 = explode(" ", $name); //dipisah perkata
        $name3 = str_split($name); //dipisah perhuruf
        $c = 0; //penghitung jumlah yang disingkat
        while (count($name3) > 30) {
            $temp = str_split($name2[count($name2) - (1 + $c)]);
            $name2[count($name2) - (1 + $c)] = $temp[0];
            $name = implode(" ", $name2);
            $name3 = str_split($name);
            $c++;
        }
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["nim"])
                ->setCellValue('C' . $counter, $row["last_name"])
                ->setCellValue('D' . $counter, $row["first_name"])
                ->setCellValue('E' . $counter, $name)
                ->setCellValue('F' . $counter, "IDN")
                ->setCellValue('G' . $counter, $bulan_lahir)
                ->setCellValue('H' . $counter, $row["tgl_lahir"])
                ->setCellValue('I' . $counter, $row["thn_lahir"])
                ->setCellValue('J' . $counter, $row["gender"])
                ->setCellValue('K' . $counter, $row["country_code"])
                ->setCellValue('L' . $counter, $row["language_code"])
                ->setCellValue('M' . $counter, '=len(C' . $counter . ')')
                ->setCellValue('N' . $counter, '=len(D' . $counter . ')')
                ->setCellValue('O' . $counter, '=len(E' . $counter . ')')
                ->setCellValue('P' . $counter, '=FIND(" ";C' . $counter . ';1)')
                ->setCellValue('Q' . $counter, '=IF(C' . $counter . '=RIGHT(E' . $counter . ';LEN(C' . $counter . '));"TRUE";"FALSE")')
                ->setCellValue('R' . $counter, '=IF(OR(' . $row["queue_confirm"] . '<31;AND(' . $row["queue_confirm"] . '>210;' . $row["queue_confirm"] . '<241));1;IF(OR(AND(' . $row["queue_confirm"] . '>30;' . $row["queue_confirm"] . '<61);AND(' . $row["queue_confirm"] . '>240;' . $row["queue_confirm"] . '<271));2;IF(OR(AND(' . $row["queue_confirm"] . '>60;' . $row["queue_confirm"] . '<91);AND(' . $row["queue_confirm"] . '>270;' . $row["queue_confirm"] . '<301));3;IF(OR(AND(' . $row["queue_confirm"] . '>90;' . $row["queue_confirm"] . '<121);AND(' . $row["queue_confirm"] . '>300;' . $row["queue_confirm"] . '<331));4;IF(OR(AND(' . $row["queue_confirm"] . '>120;' . $row["queue_confirm"] . '<151);AND(' . $row["queue_confirm"] . '>330;' . $row["queue_confirm"] . '<361));5;IF(OR(AND(' . $row["queue_confirm"] . '>150;' . $row["queue_confirm"] . '<181);AND(' . $row["queue_confirm"] . '>360;' . $row["queue_confirm"] . '<391));6;7))))))')
                ->setCellValue('S' . $counter, '=IF(' . $row["queue_confirm"] . '<211;1;2)');
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("TOEFL ITP Online BLC " . date("d-m-Y"));
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="TOEFL ITP Online BLC ' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');


    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} 
elseif (clear($_GET["download"]) === "template") {

    $file = '../template/template_data.xls';

    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
} 
elseif (clear($_GET["download"]) === "all") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.close = 0 "
            . "order by akun_online.queue_confirm";
    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setSubject("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setDescription("Rekap TOEFL ITP " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'Urutan Konfirmasi')
            ->setCellValue('C1', 'Waktu Update')
            ->setCellValue('D1', 'Waktu Konfirmasi')
            ->setCellValue('E1', 'NIM')
            ->setCellValue('F1', 'Nama')
            ->setCellValue('G1', 'Fakultas')
            ->setCellValue('H1', 'Jenjang')
            ->setCellValue('I1', 'Email')
            ->setCellValue('J1', 'No. HP')
            ->setCellValue('K1', 'No. WA')
            ->setCellValue('L1', 'Bulan Lahir')
            ->setCellValue('M1', 'Tanggal Lahir')
            ->setCellValue('N1', 'Tahun Lahir')
            ->setCellValue('O1', 'Jenis Kelamin')
            ->setCellValue('P1', 'Native Country')
            ->setCellValue('Q1', 'Native Language')
            ->setCellValue('R1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["queue_confirm"])
                ->setCellValue('C' . $counter, $row["time_update"])
                ->setCellValue('D' . $counter, $row["time_confirmation"])
                ->setCellValue('E' . $counter, $row["nim"])
                ->setCellValue('F' . $counter, $row["nama"])
                ->setCellValue('G' . $counter, $row["fakultas"])
                ->setCellValue('H' . $counter, $row["jenjang"])
                ->setCellValue('I' . $counter, $row["email"])
                ->setCellValue('J' . $counter, $row["hp"])
                ->setCellValue('K' . $counter, $row["wa"])
                ->setCellValue('L' . $counter, $row["bln_lahir"])
                ->setCellValue('M' . $counter, $row["tgl_lahir"])
                ->setCellValue('N' . $counter, $row["thn_lahir"])
                ->setCellValue('O' . $counter, $row["gender"])
                ->setCellValue('P' . $counter, $row["country_code"])
                ->setCellValue('Q' . $counter, $row["language_code"])
                ->setCellValue('R' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Rekap TOEFL ITP " . date("d-m-Y"));
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Rekap TOEFL ITP ' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} 
elseif (clear($_GET["download"]) === "nc") {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 0 "
            . "and akun_online.status = 1 "
            . "and akun_online.close != 1 "
            . "order by akun_online.id";

    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Belum Konfirmasi " . date("d-m-Y"))
            ->setSubject("Belum Konfirmasi " . date("d-m-Y"))
            ->setDescription("Belum Konfirmasi" . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'Waktu Update')
            ->setCellValue('C1', 'NIM')
            ->setCellValue('D1', 'Nama')
            ->setCellValue('E1', 'Fakultas')
            ->setCellValue('F1', 'Jenjang')
            ->setCellValue('G1', 'Email')
            ->setCellValue('H1', 'No. HP')
            ->setCellValue('I1', 'No. WA')
            ->setCellValue('J1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["time_update"])
                ->setCellValue('C' . $counter, $row["nim"])
                ->setCellValue('D' . $counter, $row["nama"])
                ->setCellValue('E' . $counter, $row["fakultas"])
                ->setCellValue('F' . $counter, $row["jenjang"])
                ->setCellValue('G' . $counter, $row["email"])
                ->setCellValue('H' . $counter, $row["hp"])
                ->setCellValue('I' . $counter, $row["wa"])
                ->setCellValue('J' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Belum Konfirmasi " . date("d-m-Y"));
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Belum Konfirmasi ' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
} 
elseif (clear($_GET["download"] === "nu")) {
    $sql = "select * FROM akun_online_daftar_nama "
            . "inner join akun_online on akun_online_daftar_nama.id = akun_online.id "
            . "where akun_online.confirmation = 0 "
            . "and akun_online.status = 0 "
            . "and akun_online.close = 0";
    $result = mysqli_query($link, $sql);

    error_reporting(E_ALL);

    ini_set('display_errors', TRUE);
    ini_set('display_startup_errors', TRUE);

    $objPHPExcel = new PHPExcel();
    date_default_timezone_set("Asia/Jakarta");

    $objPHPExcel->getProperties()
            ->setCreator("BLC UB")
            ->setLastModifiedBy("BLC UB")
            ->setTitle("Tidak Update " . date("d-m-Y"))
            ->setSubject("Tidak Update " . date("d-m-Y"))
            ->setDescription("Tidak Update " . date("d-m-Y"))
            ->setKeywords("toefl rutin online blc")
            ->setCategory("rutin");

    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No.')
            ->setCellValue('B1', 'NIM')
            ->setCellValue('C1', 'Nama')
            ->setCellValue('D1', 'Fakultas')
            ->setCellValue('E1', 'Id Akun');
    $counter = 2;
    while ($row = mysqli_fetch_assoc($result)) {
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A' . $counter, $counter - 1)
                ->setCellValue('B' . $counter, $row["nim"])
                ->setCellValue('C' . $counter, $row["nama"])
                ->setCellValue('D' . $counter, $row["fakultas"])
                ->setCellValue('E' . $counter, $row["id"]);
        $counter++;
    }
    $objPHPExcel->getActiveSheet()->setTitle("Tidak Update " . date("d-m-Y"));
    $objPHPExcel->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Tidak Update ' . date("d-m-Y") . '.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;
}