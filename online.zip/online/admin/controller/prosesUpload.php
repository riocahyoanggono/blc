<?php

include '../../model/db_connection.php';
include '../lib/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
include '../../controller/func_enc_dec.php';
$filename = $_FILES["file"]["name"];
move_uploaded_file($_FILES['file']['tmp_name'], __DIR__ . "/uploaded/" . $_FILES["file"]['name']);
$file = './uploaded/' . $filename;
$fileType = pathinfo($file, PATHINFO_EXTENSION);
if ($fileType != "xls") {
    echo "<script>window.alert('Hanya boleh file Excel');</script>";
    echo '<script>window.location = "../uploadMhs.php";</script>';
} else {
    try {
        $inputFileType = PHPExcel_IOFactory::identify($file);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($file);
    } catch (Exception $e) {
        die('Gagal Mengupload "' . pathinfo($file, PATHINFO_BASENAME) . '": ' . $e->getMessage());
    }
}

$sheet = $objPHPExcel->getSheet(0);
$highestRow = $sheet->getHighestRow();
$highestColumn = $sheet->getHighestColumn();

for ($row = 1; $row <= $highestRow; $row++) {
    $Row = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
    $data1 = mysqli_real_escape_string($link, $Row[0][0]); //no
    $data2 = mysqli_real_escape_string($link, $Row[0][1]); //nama
    $data3 = intval(mysqli_real_escape_string($link, $Row[0][2])); //nim
    $data4 = mysqli_real_escape_string($link, $Row[0][3]); //fakultas

    $data6 = mysqli_real_escape_string($link, $Row[0][4]); //hp
    $data7 = mysqli_real_escape_string($link, $Row[0][5]); //wa

    $sql5 = "select * from daftar_fakultas where singkatan = '$data4'";
    $result5 = mysqli_query($link, $sql5);
    while ($row1 = mysqli_fetch_assoc($result5)) {
        if (intval($row1["urutan"]) < 10) {
            $data5 = substr($data3, -4) . substr($data6, -4) . "0" . $row1["urutan"];
        } else {
            $data5 = substr($data3, -4) . substr($data6, -4) . $row1["urutan"];
        }
    }

    $id = 0;

    if ($data1 == "NO") {
        continue;
    } else {
        if (empty($data1)) {
            break;
        }
        $sql2 = "SELECT * FROM akun_online where user = '" . encode($data3) . "'";
        $query2 = mysqli_query($link, $sql2);
        if (mysqli_num_rows($query2) > 0) {
            continue;
        } else {
            $sql3 = "insert into akun_online values ('', '" . encode($data3) . "', '" . encode($data5) . "', 0, 0 ,0,'','',0)";
            mysqli_query($link, $sql3);
            $sql4 = "select * from akun_online where user = '" . encode($data3) . "'";
            $query4 = mysqli_query($link, $sql4);
            if (mysqli_num_rows($query4) > 0) {
                while ($row3 = mysqli_fetch_assoc($query4)) {
                    $id = $row3["id"];
                }
            }
            $sql = "insert into akun_online_daftar_nama values "
                    . "('" . $id . "', "
                    . "'" . strtoupper($data2) . "',"
                    . "'',"
                    . "'',"
                    . "'" . $data3 . "',"
                    . "'" . $data4 . "',"
                    . "'',"
                    . "'',"
                    . "'',"
                    . "'',"
                    . "'',"
                    . "'$data6',"
                    . "'$data7',"
                    . "'',"
                    . "'',"
                    . "'',"
                    . "'',"
                    . "'')";
            mysqli_query($link, $sql);
        }
    }
}

unlink($file);
echo "<script>window.alert('Sukses')</script>";
echo '<script>window.location = "../";</script>';
