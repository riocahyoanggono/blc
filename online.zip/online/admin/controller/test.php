<!DOCTYPE HTML>
<html>
    <head>

    </head>
    <body>
        <table style="width: 100%">
            <tr>
                <td style=" width: 200px">
                    <img src="blc_logo.png" style="width: 200px; float: inside">
                </td>
                <td style="text-align: center;">
                    <div style="font-size: 30pt"> 
                        Pengajuan Pengambilan Hasil
                    </div>
                </td>
            </tr>
        </table>
        <br>
        <hr style="border: solid">
        <table style="width: 100%">
            <tr>
                <td>
                    <h2>
                        Kode : SAHHWHSJ3I3
                    </h2>
                </td>
                <td>
                    image
                </td>
            </tr>
        </table>
        Nama Pemohon : RIO CAHYO A
        <br>
        Nomor Identitas : 3515929292392
        <br>
        <hr style="border: solid 1px">
    </body>
</html>