<?php

//include '../../model/db_connection.php';
//$sql = "select * from akun_online where confirmation = 1 order by queue_confirm";
//$result = mysqli_query($link, $sql);
//
//$array = $problems = array();
//
//while ($row = mysqli_fetch_assoc($result)) {
//    array_push($array, $row["queue_confirm"]);
//}
//
//$max_array = count($array);
//$j = 1;
//for ($p = 0; $p < $max_array; $p++) {
//    if ($j != $array[$p]) {
//        for ($x = $j; $x < $array[$p]; $x++) {
//            array_push($problems, $x);
//            $j++;
//        }
//    }
//    $j++;
//}
//print_r($problems);

$a = array();
for ($i = 0; $i < 8; $i++) {
    $a[$i] = \rand(0, 8);
    for ($j = 0; $j < $i; $j++) {
        while ($a[$i] === $a[$j]) {
            $a[$j] = \rand(0, 8);
        }
        
    }
}
echo $a[0];