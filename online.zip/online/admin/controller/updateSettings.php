<?php

session_start();

function clear($data) {
    return trim(stripslashes(htmlspecialchars($data)));
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $jumlah_peserta = intval(clear($_POST["jumlah_peserta"]));
        $jumlah_proctor = intval(clear($_POST["jumlah_proctor"]));
        $jumlah_sesi = intval(clear($_POST["jumlah_sesi"]));
        $rutin = intval(clear($_POST["rutin"]));
        $periode = clear($_POST["periode"]);
        $tgl_tes = clear($_POST["tgl_tes"]);
    }
    if (empty($jumlah_peserta) || empty($jumlah_proctor) || empty($jumlah_sesi)) {
        echo "<script> window.alert('DATA TIDAK TERSIMPAN! Periksa kembali data!'); history-go(-1);</script>";
        echo "<script> window.location = '../setting.php';</script>";
    } else {
        if ($jumlah_peserta % ($jumlah_proctor * $jumlah_sesi) === 0) {
            $peserta_proctor = ($jumlah_peserta / ($jumlah_proctor * $jumlah_sesi));
            $sql = "update online_settings set jumlah_peserta = $jumlah_peserta, jumlah_proctor = $jumlah_proctor, jumlah_sesi = $jumlah_sesi, peserta_proctor = $peserta_proctor, rutin = $rutin, periode = '$periode', tgl_tes = '$tgl_tes' where id = 1";
            mysqli_query($link, $sql);
            echo "<script> window.alert('Konfigurasi Sukses Dirubah');</script>";
            echo "<script> window.location = '../setting.php';</script>";
        } else {
            echo "<script> window.alert('Data tidak sesuai perhitungan. Periksa Kembali Data!'); history-go(-1);</script>";
            echo "<script> window.location = '../setting.php';</script>";
        }
    }
}