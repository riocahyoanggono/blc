<?php

session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

include '../../model/db_connection.php';

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    $sql = "update akun_online set close = 1 where not id = 1 and not confirmation = 1";
    mysqli_query($link, $sql);
    
    $sql2 = "select max(queue_confirm) m from akun_online";
    $result2 = mysqli_query($link, $sql2);
    while ($row = mysqli_fetch_assoc($result2)) {
        $max = $row["m"];
    }
    
    $sql3 = "update counter set count = '$max' where id = 4";
    $result = mysqli_query($link, $sql3);
    
    $sql4 = "update akun_online set close = 2 where not id = 1 and confirmation = 1";
    mysqli_query($link, $sql4);
    echo "<script>alert('Sistem Update Ditutup!'); history-go(-1);</script>";
    echo "<script> window.location = '../';</script>";
}