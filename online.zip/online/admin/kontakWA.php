<!DOCTYPE html>
<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
}
include './view/navbar.php';
include '../model/db_connection.php';
?>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <div class="container-fluid w3-center" style="margin-top: 70px">
        <div class="col-sm-6">
            <h2>
                <b>
                    Kontak WhatsApp Tahap 1
                </b>
            </h2>
            <div style="height: 500px; overflow-y: scroll">
                <table class="table table-responsive table-bordered table-striped" style="background-color: white;">
                    <?php
                    $sql3 = "select * from online_settings where id = 1";
                    $result3 = mysqli_query($link, $sql3);
                    while ($row = mysqli_fetch_assoc($result3)) {
                        $periode = str_replace(" ", "%20", $row["periode"]);
                        $tgl_tes = str_replace(" ", "%20", $row["tgl_tes"]);
                    }
                    $sql = "select * from akun_online_daftar_nama inner join akun_online on akun_online.id = akun_online_daftar_nama.id where akun_online.close = 0 order by akun_online.id asc";
                    $result = mysqli_query($link, $sql);
//                    $textwa = "Untuk membantu program IISMA dengan ini anda mendapatkan jadwal tes TOEFL pada tanggal 18/05/21 dan silahkan melakukan update data sesuai dengan panduan yang kami kirimkan melalui email. Jika anda tidak sedang dalam proses untuk mendaftar Program IISMA, MOHON untuk tidak melakukan update data. Untuk keterangan lebih lanjut mohon periksa Inbox dan SPAM email anda.*";
                    $textwa = "Anda%20telah%20terjadwal%20pada%20TOEFL%20ITP%20Rutin%20BLC%20Periode%20" . $periode . "%20(" . $tgl_tes . ").%20Periksa%20inbox%20dan%20spam%20email%20anda%20untuk%20keterangan%20lebih%20lanjut.%0AUntuk%20daftar%20peserta%20yang%20terjadwal%20dapat%20anda%20lihat%20di%20laman%20http://blc.ub.ac.id/jadwal-toefl-itp-rutin%0A%0A_Jika%20anda%20tidak%20menerima%20email,%20segera%20hubungi%20WhatsApp%20BLC/DM%20Instagram%20BLC_%0A%0A*HARAP%20TIDAK%20MEMBALAS%20PESAN%20INI!*";
//                    $textwa = "Anda telah terjadwal pada TOEFL ITP Rutin BLC periode XXI yang akan dilaksanakan tanggal *17 Juni 2021*. Periksa inbox dan spam email anda untuk keterangan lebih lanjut untuk daftar peserta terjadwal dapat anda lihat di laman http://blc.ub.ac.id/jadwal-toefl-itp-rutin/... . Jika anda tidak menerima email segera hubungi whatsapp BLC atau DM instagram BLC *(HARAP TIDAK MEMBALAS PESAN INI!)*";
                    
                    ?>
                    <thead class="thead-dark">
                        <tr>
                            <th style="text-align: center; vertical-align: middle">No.</th>
                            <th style="text-align: center; vertical-align: middle">NIM</th>
                            <th style="text-align: center; vertical-align: middle">Nama</th>
                            <th style="text-align: center; vertical-align: middle">Kirim Pesan WA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $c = 1;
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $c;
                                    $c++;
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $row["nim"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align: left">
                                    <?php
                                    echo $row["nama"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle; text-align: center">
                                    <a href="https://wa.me/<?php echo substr_replace($row["wa"], "62", 0, 1) . "?text=" . $textwa; ?>" target="_blank">
                                        <?php
                                        echo $row["wa"];
                                        ?>
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-sm-6">
            <h2>
                <b>
                    Kontak WhatsApp Tahap 2
                </b>
            </h2>
            <div style="height: 500px; overflow-y: scroll">
                <table class="table table-responsive table-bordered table-striped" style="background-color: white;">
                    <?php
                    $sql2 = "select * from akun_online_daftar_nama inner join akun_online on akun_online.id = akun_online_daftar_nama.id where akun_online.close = 0 and akun_online.confirmation = 0 order by akun_online.id asc";
                    $result2 = mysqli_query($link, $sql2);
//                    $textwa2 = "Untuk membantu program IISMA dengan ini anda mendapatkan jadwal tes TOEFL, silahkan melakukan update data pada http://toeflrutin.blc.ub.ac.id/online sesuai dengan panduan yang kami kirimkan melalui email. Jika anda tidak sedang dalam proses untuk mendaftar Program IISMA, MOHON untuk tidak melakukan update data. Untuk keterangan lebih lanjut mohon periksa Inbox dan SPAM email anda.*";
                   $textwa2 = "Segera%20lakukan%20update%20data%20dan%20konfirmasi%20data%20sesuai%20dengan%20panduan%20yang%20sudah%20di%20email.%20Apabila%20anda%20tidak%20melakukan%20update%20data%20dan/atau%20konfirmasi%20data%20hingga%20batas%20waktu%20sesuai%20dengan%20ketentuan%20email,%20*maka%20nama%20anda%20akan%20digantikan%20oleh%20peserta%20lain*.%20Jika%20anda%20berniat%20untuk%20mengundurkan%20diri,%20maka%20lakukan%20pendaftaran%20ulang%20pada%20laman%20https://bit.ly/toefl_itp_rutin_blc%20dan%20menunggu%20kembali%20untuk%20dijadwalkan%20ulang.%20Abaikan%20pesan%20ini%20jika%20anda%20sudah%20melakukan%20update%20data.%0A%0A*[HARAP%20TIDAK%20MEMBALAS%20PESAN%20INI!]*";
                    ?>
                    <thead class="thead-dark">
                        <tr>
                            <th style="text-align: center; vertical-align: middle">No.</th>
                            <th style="text-align: center; vertical-align: middle">NIM</th>
                            <th style="text-align: center; vertical-align: middle">Nama</th>
                            <th style="text-align: center; vertical-align: middle">Kirim Pesan WA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $d = 1;
                        while ($row = mysqli_fetch_assoc($result2)) {
                            ?>
                            <tr>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $d++;
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $row["nim"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align: left">
                                    <?php
                                    echo $row["nama"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle; text-align: center">
                                    <a href="https://wa.me/<?php echo substr_replace($row["wa"], "62", 0, 1) . "?text=" . $textwa2; ?>" target="_blank">
                                        <?php
                                        echo $row["wa"];
                                        ?>
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>