<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './view/navbar.php';
    $sql = "select * FROM daftar_fakultas";
    $result = mysqli_query($link, $sql);
    ?>
    <body>
        <div class="container w3-center" style="margin-top: 70px">
            <h2>
                Tambah Mahasiswa Baru
            </h2>
        </div>
        <div class="container" style="margin-top: 20px">
            <form action="controller/addMHS.php" method="POST">
                <div class="container" style="width: 55%">
                    NIM <input name="nim" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px">
                    Nama <input name="nama" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px;">
                    Fakultas <select name="fakultas" class="w3-right" style="width: 75%; height: 28px" required>
                        <option value=""></option>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result)) {
                                ?><option value="<?php echo $row["singkatan"]; ?>"><?php echo $row["nama_fakultas"] ?></option><?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px">
                    Password <input name="password" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container w3-center" style="margin-top: 20px">
                    <button type="submit" class="btn btn-info">
                        Tambahkan
                    </button>
                </div>
            </form>
        </div>
    </body>
    <?php
}