<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './view/navbar.php';
    $sql2 = "select * from online_settings";
    $result2 = mysqli_query($link, $sql2);
    while ($row2 = mysqli_fetch_assoc($result2)) {
        if (intval($row2["rutin"]) === 1) {
            $sql = "select * FROM daftar_fakultas where not urutan = 17 order by urutan asc";
        } elseif (intval($row2["rutin"]) === 2) {
            $sql = "select * FROM daftar_fakultas where urutan = 17";
        }
    }
    $result = mysqli_query($link, $sql);
    ?>
    <body>
        <div class="container w3-center" style="margin-top: 70px">
            <h2>
                Tambah Mahasiswa Baru
            </h2>
        </div>
        <div class="container" style="margin-top: 20px">
            <form action="controller/addMHS.php" method="POST">
                <div class="container" style="width: 55%">
                    NIM <input name="nim" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px">
                    Nama <input name="nama" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px;">
                    Fakultas <select name="fakultas" class="w3-right" style="width: 75%; height: 28px" required>
                        <option value=""></option>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result)) {
                                ?><option value="<?php echo $row["singkatan"]; ?>"><?php echo $row["nama_fakultas"] ?></option><?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px">
                    No. HP <input name="hp" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container" style="width: 55%; margin-top: 15px">
                    No. WA <input name="wa" type="text" class="w3-right" style="width: 75%" required>
                </div>
                <div class="container w3-center" style="margin-top: 20px">
                    <button type="submit" class="btn btn-info" style="margin-right: 25px">
                        Tambahkan
                    </button>
                    <a style="text-decoration: none" class="w3-button w3-round-large w3-yellow w3-hover-orange" href="controller/addDummy.php">
                        Tambah Data Dummy
                    </a>
                </div>
            </form>
        </div>
    </body>
    <?php
}    