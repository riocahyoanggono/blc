<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src="https://www.w3schools.com/lib/w3.js"></script>
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>
        <?php
        $q = intval($_GET['q']);
        include '../../model/db_connection.php';
        $sql = "select * from jadwal_tes_online inner join akun_online_daftar_nama on jadwal_tes_online.id_peserta = akun_online_daftar_nama.id where jadwal_tes_online.id_tanggal_tes = '$q'";
        $result = mysqli_query($link, $sql);
        ?>
        <table class="table table-responsive table-bordered table-striped" id="tabelBarang">
            <tr>
                <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">
                    Nama
                </th>
                <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">
                    NIM
                </th>
                <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">
                    Fakultas
                </th>
            </tr>

            <?php
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <tr class="item">
                    <td style="vertical-align : middle;text-align:center;">
                        <?php echo $row["nama"]?>
                    </td>
                    <td style="vertical-align : middle;text-align:center;">
                        <?php echo $row["nim"]?>
                    </td>
                    <td style="vertical-align : middle;text-align:center;">
                        <?php echo $row["fakultas"]?>
                    </td>
                </tr>
                
                <?php
            }
            ?>
        </table>
    </body>
</html>



