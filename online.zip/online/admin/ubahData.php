<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    include '../model/db_connection.php';
    $sql7 = "select * from online_settings";
    $result7 = mysqli_query($link, $sql7);

    $sql2 = "select * from akun_online_daftar_nama where id = " . $_GET["id"];
    $result2 = mysqli_query($link, $sql2);

    if (mysqli_num_rows($result2) > 0) {
        $_SESSION["changed_id"] = $_GET["id"];
        while ($row = mysqli_fetch_assoc($result2)) {
            ?>
            <body>
                <div class="container" style="margin-top: 70px; overflow-x: auto; vertical-align: middle">
                    <form action="controller/prosesUbah.php" method="POST">
                        <div class="row">
                            <div class="container" style="width: 50%">
                                NIM <input name="nim" type="text" class="w3-right" style="width: 75%" value="<?php echo $row["nim"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Nama Depan <input name="first_name" type="text" class="w3-right" style="width: 75%" value="<?php echo $row["first_name"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Nama Belakang <input name="last_name" type="text" class="w3-right" style="width: 75%" value="<?php echo $row["last_name"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Nama Lengkap <input name="full_name" type="text" class="w3-right" style="width: 75%" value="<?php echo $row["nama"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Fakultas <select name="fakultas" class="w3-right" style="width: 75%; height: 28px">
                                    <?php
                                    while ($row8 = mysqli_fetch_assoc($result7)) {
                                        if (intval($row8["rutin"]) === 1) {
                                            $sql3 = "select * from daftar_fakultas where not urutan = 17 order by urutan asc";
                                        } elseif (intval($row8["rutin"]) === 2) {
                                            $sql3 = "select * from daftar_fakultas where urutan = 17";
                                        }
                                    }

                                    $result3 = mysqli_query($link, $sql3);
                                    if (mysqli_num_rows($result3) > 0) {
                                        while ($row2 = mysqli_fetch_assoc($result3)) {
                                            ?>
                                            <option value="<?php echo $row2["singkatan"] ?>" <?php if ($row2["singkatan"] == $row["fakultas"]) { ?>selected<?php } ?>>
                                                <?php echo $row2["singkatan"] ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Jenjang <select name="jenjang" class="w3-right" style="width: 75%; height: 28px">
                                    <option value="D3" <?php if ($row["jenjang"] == "D3") { ?>selected<?php } ?>>
                                        D3
                                    </option>
                                    <option value="S1" <?php if ($row["jenjang"] == "S1") { ?>selected<?php } ?>>
                                        S1
                                    </option>
                                    <option value="S2" <?php if ($row["jenjang"] == "S2") { ?>selected<?php } ?>>
                                        S2
                                    </option>
                                    <option value="S3" <?php if ($row["jenjang"] == "S3") { ?>selected<?php } ?>>
                                        S3
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Tanggal Lahir <input type="date" name="tgl_lahir" style="width: 75%" class="w3-right" value="<?php echo $row["thn_lahir"] . "-" . $row["bln_lahir"] . "-" . $row["tgl_lahir"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Jenis Kelamin <select name="gender" class="w3-right" style="width: 75%; height: 28px">
                                    <option value="M" <?php if ($row["gender"] == "M") { ?>selected<?php } ?>>PRIA</option>
                                    <option value="F" <?php if ($row["gender"] == "F") { ?>selected<?php } ?>>WANITA</option>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Email <input type="email" name="email" style="width: 75%" class="w3-right" value="<?php echo $row["email"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                No. HP <input type="text" name="hp" style="width: 75%" class="w3-right" maxlength="15" value="<?php echo $row["hp"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                No. WA <input type="text" name="wa" style="width: 75%" class="w3-right" maxlength="15" value="<?php echo $row["wa"] ?>" required>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Kebangsaan <select name="nat_country" class="w3-right" style="width: 75%; height: 28px;">
                                    <?php
                                    $sql5 = "SELECT * FROM akun_online_daftar_nama where id = " . $_GET["id"];
                                    $result5 = mysqli_query($link, $sql5);
                                    if (mysqli_num_rows($result5) > 0) {
                                        while ($row3 = mysqli_fetch_array($result5)) {
                                            $countrySelection = $row3["nat_country"];
                                            $languageSelection = $row3["nat_language"];
                                        }
                                    }
                                    $sql4 = "select * FROM nat_country_list";
                                    $result4 = mysqli_query($link, $sql4);
                                    if (mysqli_num_rows($result4) > 0) {
                                        while ($row1 = mysqli_fetch_array($result4)) {
                                            ?>
                                            <option value="<?php echo $row1["id"] ?>" <?php if ($row1["country"] == $countrySelection) { ?>selected<?php } ?>><?php echo $row1["country"] ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container" style="width: 50%">
                                Bahasa Asli <select name="nat_language" class="w3-right" style="width: 75%; height: 28px;">
                                    <?php
                                    $sql6 = "select * FROM nat_language_list";
                                    $result6 = mysqli_query($link, $sql6);
                                    if (mysqli_num_rows($result6) > 0) {
                                        while ($row1 = mysqli_fetch_array($result6)) {
                                            ?>
                                            <option value="<?php echo $row1["id"] ?>" <?php if ($row1["language"] == $languageSelection) { ?>selected<?php } ?>><?php echo $row1["language"] ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 10px">
                            <div class="container w3-center" style="width: 50%">
                                <button type="submit" style="margin-right: 20px" class="w3-button w3-blue w3-round-large w3-hover-cyan">
                                    Ubah
                                </button>
                                <a href="../admin/detail.php?id=<?php echo $_GET["id"]; ?>" style="text-decoration: none" class="w3-button w3-pink w3-round-large w3-hover-red">
                                    Batal
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </body>
            <?php
        }
    }
}