<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    ?>
    <body>
        <div class="container w3-center" style="margin-top: 70px">
            <form method="POST" enctype="multipart/form-data" action="controller/prosesUpload.php">
                <input type="file" name="file" required style="margin: auto">
                <div class="row" style="margin: auto">
                    <button type="submit" value="Upload" style="margin-top: 10px">Upload</button>
                </div>
            </form>
            
            <a style="margin-top: 10px; text-decoration: none" href="controller/download.php?download=template"><button style="margin-top: 10px">Download Template</button></a>
        </div>
    </body>
    <?php
}