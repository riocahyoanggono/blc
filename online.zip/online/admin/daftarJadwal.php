<!DOCTYPE HTML>
<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    ?><body>
        <?php
        include '../model/db_connection.php';
        include './view/navbar.php';
        $sql = "select * from tanggal_tes";
        $result = mysqli_query($link, $sql);
        if (mysqli_num_rows($result) > 0) {
            ?>
        <div class="container w3-center" style="margin-top: 70px">
                <h3>
                    <strong>
                        Daftar Jadwal TOEFL ITP
                    </strong>
                </h3>
            </div>
            <div class="w3-center container" style="overflow: auto; height: auto; width: 50%">
                <table class="table table-responsive table-bordered table-striped" id="tabelBarang">
                    <thead class="thead-dark">
                        <tr>
                            <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">ID Jadwal</th>
                            <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Tanggal</th>
                            <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Waktu</th>
                            <th style="text-align: center; cursor: pointer" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr class="item">
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $row["id_tanggal"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $row["tgl"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    echo $row["waktu"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center;">
                                    <?php
                                    switch ($row["status"]) {
                                        case 1:
                                            echo "Sudah Dilaksanakan";
                                            break;
                                        case 0:
                                            echo "Belum Dilaksanakan";
                                            break;
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>

            </div>
            <div class="container w3-center" style="width: 50%">
                <hr style="height:2px;color:gray;background-color:gray;width: auto;">
                <i class="w3-center">
                    Pilih jadwal untuk melihat detail peserta
                </i>
                <div class="containter w3-center" style="margin: 15px auto">
                    <form>
                        <select name="id_tanggal" onchange="showUser(this.value)">
                            <option value="">Pilih Tanggal</option>
                            <?php
                            $sql4 = "select * from tanggal_tes";
                            $result4 = mysqli_query($link, $sql4);
                            if (mysqli_num_rows($result4) > 0) {
                                while ($row = mysqli_fetch_assoc($result4)) {
                                    ?>
                                    <option value="<?php echo $row["id_tanggal"] ?>"><?php echo $row["id_tanggal"] . ". " . $row["tgl"] ?></option>                            
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </form>
                </div>
                <div class="w3-center container" id="result">
                </div> 
            </div>
            <script>
                function showUser(str) {
                    if (str == "") {
                        document.getElementById("result").innerHTML = "";
                        return;
                    } else {
                        if (window.XMLHttpRequest) {
                            // code for IE7+, Firefox, Chrome, Opera, Safari
                            xmlhttp = new XMLHttpRequest();
                        } else {
                            // code for IE6, IE5
                            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                        xmlhttp.onreadystatechange = function () {
                            if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("result").innerHTML = this.responseText;
                            }
                        };
                        xmlhttp.open("GET", "./lib/showJadwalPeserta.php?q=" + str, true);
                        xmlhttp.send();
                    }
                }
            </script>
        </body>
        <?php
    }
}

