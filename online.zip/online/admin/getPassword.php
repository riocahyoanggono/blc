<?php
session_start();

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    if (empty($_POST["nim"])) {
        ?>
        <script>
            window.location = "../";
        </script>
        <?php
    } else {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            include './view/navbar.php';
            include '../model/db_connection.php';
            include '../controller/func_enc_dec.php';

            $sql = "select * from akun_online where user = '" . encode(clear($_POST["nim"])) . "'";
            $result = mysqli_query($link, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <body>
                        <div class="container w3-center" style="margin-top: 70px">
                            <div class="row" style="margin: auto">
                                NIM : <?php echo clear($_POST["nim"]); ?>
                            </div>
                            <div class="row" style="margin: auto">
                                Password : <?php echo decode($row["pass"]); ?>
                            </div>
                        </div>
                    </body>
                    <?php
                }
            } else {
                echo "<script>window.alert('NIM ".  clear($_POST["nim"])." Tidak Ditemukan!!')</script>";
                echo '<script>window.location = "viewPassword.php";</script>';
            }
        } else {
            echo '<script>window.location = "../";</script>';
        }
    }
}