<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './view/navbar.php';
    $sql = "select * FROM online_settings where id = 1";
    $result = mysqli_query($link, $sql);
    ?>
    <body>
        <div class="container w3-center" style="margin-top: 70px">
            <h2>
                Ubah Konfigurasi Sistem
            </h2>
        </div>
        <div class="container" style="margin-top: 20px">
            <form action="controller/updateSettings.php" method="POST">

                <div class="container" style="width: 35%">
                    Jumlah Maksimum Peserta <input name="jumlah_peserta" type="text" class="w3-right" style="width: 30%" required>
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jumlah Proctor <input name="jumlah_proctor" type="text" class="w3-right" style="width: 30%" required>
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jumlah Sesi <input name="jumlah_sesi" type="text" class="w3-right" style="width: 30%" required>
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jenis Tes <select name="rutin" class="w3-right" style="width: 30%; height: 28px" required>
                        <option disabled="" selected="">
                        </option>
                        <option value="1">
                            Rutin
                        </option>
                        <option value="2">
                            Kediri
                        </option>
                    </select>
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Periode <input name="periode" type="text" class="w3-right" style="width: 30%" required>
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Tanggal Tes<input name="tgl_tes" type="text" class="w3-right" style="width: 30%" required>
                </div>
                <div class="container w3-center" style="margin-top: 20px">
                    <a style="text-decoration: none; margin-right: 25px" class="w3-button w3-round-large w3-yellow w3-hover-orange" href="controller/lastcounter.php">
                        <?php
                        $sql2 = "select * from counter where id = 4";
                        $result2 = mysqli_query($link, $sql2);
                        while ($row2 = mysqli_fetch_assoc($result2)) {
                            if ($row2["count"] > 0) {
                                ?>
                                Disable Last Counter
                                <?php
                            } else {
                                ?>
                                Enable Last Counter
                                <?php
                            }
                        }
                        ?>

                    </a>
                    
                    <button type="submit" class="btn btn-info">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
            <div class="container w3-center" style="width: 35%; margin-top: 20px">
                <h3>
                    <strong>
                        Konfigurasi Sistem Saat ini
                    </strong>
                </h3>
                <hr style="border: 1px solid black">
            </div>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <div class="container" style="width: 35%">
                    Jumlah Maksimum Peserta <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["jumlah_peserta"] ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jumlah Proctor <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["jumlah_proctor"] ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jumlah Sesi <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["jumlah_sesi"] ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jumlah Peserta/Proctor <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["peserta_proctor"] ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Jenis Tes <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php
                    if (intval($row["rutin"]) === 1) {
                        echo "Rutin";
                    } elseif (intval($row["rutin"]) === 2) {
                        echo "Kediri";
                    }
                    ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px">
                    Periode <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["periode"] ?>">
                </div>
                <div class="container" style="width: 35%; margin-top: 10px; margin-bottom: 10px">
                    Tanggal Tes <input disabled="" type="text" class="w3-right" style="width: 30%" value="<?php echo $row["tgl_tes"] ?>">
                </div>
                <?php
            }
            ?>

        </div>
    </body>
    <?php
}