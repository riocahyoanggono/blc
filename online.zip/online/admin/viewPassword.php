<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    ?>
    <body>
        <div class="container w3-center" style="margin-top: 70px">
            <form method="POST" action="getPassword.php">
                <input type="text" name="nim" required style="margin: auto" autocomplete="off" placeholder="Masukkan NIM...">
                <div class="row" style="margin: auto">
                    <button type="submit" style="margin-top: 10px">Cek Password</button>
                </div>
            </form>
        </div>
    </body>
    <?php
}
