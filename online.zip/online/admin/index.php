<!DOCTYPE html>
<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
}
include './view/navbar.php';
include '../model/db_connection.php';
include './controller/glitch_counter.php';

$glitch = getGlitch($link);
?>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <div class="container" style="margin-top: 70px">
        <?php
        //sudah update
        $sql2 = "SELECT count(status) as s from akun_online where status = 1 and not id = 1 and close = 0";
        $result2 = mysqli_query($link, $sql2);
        while ($row2 = mysqli_fetch_assoc($result2)) {
            $s = $row2["s"];
        }
        //sudah update dan sudah konfirmasi
        $sql3 = "select count(confirmation) as c from akun_online where confirmation = 1 and not id = 1";
        $result3 = mysqli_query($link, $sql3);
        while ($row3 = mysqli_fetch_assoc($result3)) {
            $c = $row3["c"];
        }
        //urutan konfirmasi terakhir
        $sql4 = "select max(queue_confirm) as mqc from akun_online";
        $result4 = mysqli_query($link, $sql4);
        while ($row4 = mysqli_fetch_assoc($result4)) {
            $mqc = $row4["mqc"];
        }
        //seluruh data
        $sql5 = "select count(id) as i from akun_online where not id = 1";
        $result5 = mysqli_query($link, $sql5);
        while ($row5 = mysqli_fetch_assoc($result5)) {
            $i = $row5["i"];
        }
        $sql8 = "select count(id) as i2 from akun_online where not id = 1 and close = 0";
        $result8 = mysqli_query($link, $sql8);
        while ($row8 = mysqli_fetch_assoc($result8)) {
            $i2 = $row8["i2"];
        }
        //sudah update dan beium konfirmasi 
        $sql6 = "select count(id) as nc from akun_online where confirmation = 0 and not id = 1 and status = 1 and close = 0";
        $result6 = mysqli_query($link, $sql6);
        while ($row6 = mysqli_fetch_assoc($result6)) {
            $nc = $row6["nc"];
        }
        $sql7 = "select count(id) as nu from akun_online where status = 0 and not id = 1 and close = 0";
        $result7 = mysqli_query($link, $sql7);
        while ($row7 = mysqli_fetch_assoc($result7)) {
            $nu = $row7["nu"];
        }
        $sql9 = "select * from akun_online where confirmation = 1";
        $result9 = mysqli_query($link, $sql9);
        $counter = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        while ($row9 = mysqli_fetch_assoc($result9)) {
            if ($row9["queue_confirm"] < 31) {
                $counter[0] ++;
            } elseif ($row9["queue_confirm"] < 61) {
                $counter[1] ++;
            } elseif ($row9["queue_confirm"] < 91) {
                $counter[2] ++;
            } elseif ($row9["queue_confirm"] < 121) {
                $counter[3] ++;
            } elseif ($row9["queue_confirm"] < 151) {
                $counter[4] ++;
            } elseif ($row9["queue_confirm"] < 181) {
                $counter[5] ++;
            } elseif ($row9["queue_confirm"] < 211) {
                $counter[6] ++;
            } elseif ($row9["queue_confirm"] < 241) {
                $counter[7] ++;
            } elseif ($row9["queue_confirm"] < 271) {
                $counter[8] ++;
            } elseif ($row9["queue_confirm"] < 301) {
                $counter[9] ++;
            } elseif ($row9["queue_confirm"] < 331) {
                $counter[10] ++;
            } elseif ($row9["queue_confirm"] < 361) {
                $counter[11] ++;
            } elseif ($row9["queue_confirm"] < 391) {
                $counter[12] ++;
            } else {
                $counter[13] ++;
            }
        }
        ?>
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang sudah update data : <?php
            echo $s . " / " . $i2 . " (";
            if ($s == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($s / $i2) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=all" class="w3-right" style="text-decoration: none"><button <?php if ($i == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Semua Data</button></a>
    </div>

    <div class="container" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang tidak update : <?php
            echo $nu . " / " . $i2 . " (";
            if ($nu == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($nu / $i2) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=nu" class="w3-right" style="text-decoration: none"><button <?php if ($i - $c == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Tidak Update</button></a>
    </div>
    <div class="container" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang sudah konfirmasi : <?php
            echo $c . " / " . 420 . " (";
            if ($c == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($c / 420) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=upload" class="w3-right" style="text-decoration: none"><button <?php if ($c == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Upload Sistem</button></a>
        <a href="controller/download.php?download=upload_beta" class="w3-right" style="margin-right: 5px; text-decoration: none"><button <?php if ($c == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Upload Sistem (Beta)</button></a>
    </div>
    <div class="container" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang belum konfirmasi : <?php
            echo $nc . " / " . $s . " (";
            if ($nc == 0 || $s == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($nc / $s) * 100, 2) . "%)";
            }
            ?>
        </a>
        <a href="controller/download.php?download=nc" class="w3-right" style="text-decoration: none">
            <button <?php if ($nc == 0) {
                ?>class="btn" disabled <?php
                } else {
                    ?> class="btn w3-hover-blue" <?php }
                ?>>
                Export Excel Belum Konfirmasi
            </button>
        </a>
    </div>
    <?php
    if (count($glitch) > 0) {
        ?>
        <div class="container" style="margin-top: 10px">
            Glitch = 
            <?php
            for ($x = 0; $x < count($glitch); $x++) {
                echo $glitch[$x];
                if ($x != count($glitch) - 1) {
                    echo ',';
                }
            }
            ?> | No. of glitch = <?php echo count($glitch); ?>
        </div>
    <?php }
    ?>
    <div class="container w3-center" style="margin-top: 10px">
        <div class="container">
            <h4 class="w3-center">
                Download Kontak
            </h4>
        </div>
        <div class="container">
            <table class="w3-center table" style="overflow-x: auto">
                <tr>
                    <td>
                        <table class="table">
                            <tr>
                                <td colspan="7">
                                    <a style="text-align: center; text-decoration: none">
                                        Sesi 1
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=1"><button <?php if ($mqc <= 0) { ?>disabled<?php } ?> class="btn">Proctor<br>1</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 30) {
                                        echo 'Complete';
                                    } elseif ($mqc < 1) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[0];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=2"><button <?php if ($mqc <= 30) { ?>disabled<?php } ?> class="btn">Proctor<br>2</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 60) {
                                        echo 'Complete';
                                    } elseif ($mqc < 31) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[1];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=3"><button <?php if ($mqc <= 60) { ?>disabled<?php } ?> class="btn">Proctor<br>3</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 90) {
                                        echo 'Complete';
                                    } elseif ($mqc < 61) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[2];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=4"><button <?php if ($mqc <= 90) { ?>disabled<?php } ?> class="btn">Proctor<br>4</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 120) {
                                        echo 'Complete';
                                    } elseif ($mqc < 91) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[3];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=5"><button <?php if ($mqc <= 120) { ?>disabled<?php } ?> class="btn">Proctor<br>5</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 150) {
                                        echo 'Complete';
                                    } elseif ($mqc < 121) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[4];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=6"><button <?php if ($mqc <= 150) { ?>disabled<?php } ?> class="btn">Proctor<br>6</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 180) {
                                        echo 'Complete';
                                    } elseif ($mqc < 151) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[5];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=7"><button <?php if ($mqc <= 180) { ?>disabled<?php } ?> class="btn">Proctor<br>7</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 210) {
                                        echo 'Complete';
                                    } elseif ($mqc < 181) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[6];
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="7">
                                    <a style="text-align: center; text-decoration: none">
                                        Sesi 2
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=8"><button <?php if ($mqc <= 210) { ?>disabled<?php } ?> class="btn">Proctor<br>1</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 240) {
                                        echo 'Complete';
                                    } elseif ($mqc < 211) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[7];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=9"><button <?php if ($mqc <= 240) { ?>disabled<?php } ?> class="btn">Proctor<br>2</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 270) {
                                        echo 'Complete';
                                    } elseif ($mqc < 241) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[8];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=10"><button <?php if ($mqc <= 270) { ?>disabled<?php } ?> class="btn">Proctor<br>3</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 300) {
                                        echo 'Complete';
                                    } elseif ($mqc < 271) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[9];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=11"><button <?php if ($mqc <= 300) { ?>disabled<?php } ?> class="btn">Proctor<br>4</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 330) {
                                        echo 'Complete';
                                    } elseif ($mqc < 301) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[10];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=12"><button <?php if ($mqc <= 330) { ?>disabled<?php } ?> class="btn">Proctor<br>5</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 360) {
                                        echo 'Complete';
                                    } elseif ($mqc < 331) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[11];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=13"><button <?php if ($mqc <= 360) { ?>disabled<?php } ?> class="btn">Proctor<br>6</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 390) {
                                        echo 'Complete';
                                    } elseif ($mqc < 361) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[12];
                                    ?>
                                </td>
                                <td>
                                    <a style="margin: 3px; text-decoration: none" href="controller/download.php?download=proctor&no=14"><button <?php if ($mqc <= 390) { ?>disabled<?php } ?> class="btn">Proctor<br>7</button></a>
                                    <br>
                                    <?php
                                    if ($mqc >= 420) {
                                        echo 'Complete';
                                    } elseif ($mqc < 391) {
                                        echo 'Not Available';
                                    } else {
                                        echo 'In Progress';
                                    }
                                    ?>
                                    <br>
                                    <?php
                                    echo $counter[13];
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="w3-center container" style="overflow: auto; height: 500px; font-size: 9pt; margin-bottom: 50px">
        <table class="table table-responsive table-bordered table-striped" id="tabelBarang">
            <thead class="thead-dark">
                <tr>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">No.</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Antrian Konfirmasi</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">NIM</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Nama</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Fakultas</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Status</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Waktu Update</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Konfirmasi</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Waktu Konfirmasi</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Proctor</th>
                    <th style="text-align: center; cursor: pointer; vertical-align: middle" onclick="w3.sortHTML('#tabelBarang', '.item', 'td:nth-child(1)')">Sesi</th>
                </tr>
            </thead>

            <tbody>

                <?php
                include '../model/db_connection.php';
                $sql = "select * from akun_online_daftar_nama inner join akun_online on akun_online.id = akun_online_daftar_nama.id order by akun_online.id asc";
                $result = mysqli_query($link, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $c = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?> 
                        <tr class="item">
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $c;
                                $c++;
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $row["queue_confirm"];
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <a href="detail.php?id=<?php echo $row["id"] ?>"><?php
                                    echo $row["nim"];
                                    ?>
                                </a>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $row["nama"];
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $row["fakultas"];
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center; <?php if ($row["status"] == 1) { ?>background-color: lime; <?php } else { ?> color: white; background-color: #ff0000; <?php } ?>">
                                <?php
                                switch ($row["status"]) {
                                    case 1:
                                        echo 'Sudah Update Data';
                                        break;
                                    default:
                                        echo 'Belum Update Data';
                                        break;
                                }
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $row["time_update"];
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center; <?php if ($row["confirmation"] == 1) { ?>background-color: lime; <?php } else { ?> color: white; background-color: #ff880b; <?php } ?>">
                                <?php
                                switch ($row["confirmation"]) {
                                    case 1:
                                        echo 'Data Terkonfirmasi';
                                        break;
                                    default:
                                        echo 'Data Belum Dikonfirmasi';
                                        break;
                                }
                                ?>
                            </td>

                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                echo $row["time_confirmation"];
                                ?>
                            </td>

                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                if ($row["queue_confirm"] < 31 && $row["queue_confirm"] > 0 || $row["queue_confirm"] > 210 && $row["queue_confirm"] < 241) {
                                    echo 1;
                                } elseif ($row["queue_confirm"] < 61 && $row["queue_confirm"] > 30 || $row["queue_confirm"] > 240 && $row["queue_confirm"] < 271) {
                                    echo 2;
                                } elseif ($row["queue_confirm"] < 91 && $row["queue_confirm"] > 60 || $row["queue_confirm"] > 270 && $row["queue_confirm"] < 301) {
                                    echo 3;
                                } elseif ($row["queue_confirm"] < 121 && $row["queue_confirm"] > 90 || $row["queue_confirm"] > 300 && $row["queue_confirm"] < 331) {
                                    echo 4;
                                } elseif ($row["queue_confirm"] < 151 && $row["queue_confirm"] > 120 || $row["queue_confirm"] > 330 && $row["queue_confirm"] < 361) {
                                    echo 5;
                                } elseif ($row["queue_confirm"] < 181 && $row["queue_confirm"] > 150 || $row["queue_confirm"] > 360 && $row["queue_confirm"] < 391) {
                                    echo 6;
                                } elseif ($row["queue_confirm"] < 211 && $row["queue_confirm"] > 180 || $row["queue_confirm"] > 390 && $row["queue_confirm"] < 421) {
                                    echo 7;
                                }
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center;">
                                <?php
                                if ($row["queue_confirm"] <= 210 && $row["queue_confirm"] > 0) {
                                    echo 1;
                                } elseif ($row["queue_confirm"] > 210) {
                                    echo 2;
                                }
                                ?>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>