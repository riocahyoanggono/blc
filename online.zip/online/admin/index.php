<!DOCTYPE html>
<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
}
include './view/navbar.php';
include '../model/db_connection.php';
include './controller/glitch_counter.php';

$glitch = getGlitch($link);
?>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

    <?php
    $sql21 = "select * from online_settings";
    $result10 = mysqli_query($link, $sql21);
    while ($row = mysqli_fetch_assoc($result10)) {
        $jumlah_peserta = intval($row["jumlah_peserta"]);
        $jumlah_proctor = intval($row["jumlah_proctor"]);
        $jumlah_sesi = intval($row["jumlah_sesi"]);
        $peserta_proctor = intval($row["peserta_proctor"]);
    }
    //sudah update
    $sql2 = "SELECT count(status) as s from akun_online where status = 1 and not id = 1 and close = 0";
    $result2 = mysqli_query($link, $sql2);
    while ($row2 = mysqli_fetch_assoc($result2)) {
        $s = $row2["s"];
    }
    //sudah update dan sudah konfirmasi
    $sql3 = "select count(confirmation) as c from akun_online where confirmation = 1 and not id = 1";
    $result3 = mysqli_query($link, $sql3);
    while ($row3 = mysqli_fetch_assoc($result3)) {
        $c = $row3["c"];
    }
    //urutan konfirmasi terakhir
    $sql4 = "select max(queue_confirm) as mqc from akun_online";
    $result4 = mysqli_query($link, $sql4);
    while ($row4 = mysqli_fetch_assoc($result4)) {
        $mqc = $row4["mqc"];
    }
    //seluruh data
    $sql5 = "select count(id) as i from akun_online where not id = 1";
    $result5 = mysqli_query($link, $sql5);
    while ($row5 = mysqli_fetch_assoc($result5)) {
        $i = $row5["i"];
    }
    $sql8 = "select count(id) as i2 from akun_online where not id = 1 and close = 0";
    $result8 = mysqli_query($link, $sql8);
    while ($row8 = mysqli_fetch_assoc($result8)) {
        $i2 = $row8["i2"];
    }
    //sudah update dan beium konfirmasi 
    $sql6 = "select count(id) as nc from akun_online where confirmation = 0 and not id = 1 and status = 1 and close = 0";
    $result6 = mysqli_query($link, $sql6);
    while ($row6 = mysqli_fetch_assoc($result6)) {
        $nc = $row6["nc"];
    }
    $sql7 = "select count(id) as nu from akun_online where status = 0 and not id = 1 and close = 0";
    $result7 = mysqli_query($link, $sql7);
    while ($row7 = mysqli_fetch_assoc($result7)) {
        $nu = $row7["nu"];
    }
    $sql9 = "select * from akun_online where confirmation = 1";
    $result9 = mysqli_query($link, $sql9);
    for ($x = 0; $x < $jumlah_proctor; $x++) {
        for ($y = 0; $y < $jumlah_sesi; $y++) {
            $counter[$x][$y] = 0;
        }
    }
    while ($row9 = mysqli_fetch_assoc($result9)) {
        $sesi = ceil(intval($row9["queue_confirm"]) / ($jumlah_peserta / $jumlah_sesi));
        $proctor = ceil(intval($row9["queue_confirm"]) / $peserta_proctor) - $jumlah_proctor * ($sesi - 1);
        $counter[$proctor - 1][$sesi - 1] ++;
    }
    ?>


    <div class="container-fluid" style="margin-top: 70px">    
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang sudah update data : <?php
            echo $s . " / " . $i2 . " (";
            if ($s == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($s / $i2) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=all" class="w3-right" style="text-decoration: none"><button <?php if ($i == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Semua Data</button></a>
    </div>

    <div class="container-fluid" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang tidak update : <?php
            echo $nu . " / " . $i2 . " (";
            if ($nu == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($nu / $i2) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=nu" class="w3-right" style="text-decoration: none"><button <?php if ($i - $c == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Tidak Update</button></a>
    </div>
    <div class="container-fluid" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang sudah konfirmasi : <?php
            echo $c . " / " . $jumlah_peserta . " (";
            if ($c == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($c / $jumlah_peserta) * 100, 2) . "%)";
            }
            ?></a>
        <a href="controller/download.php?download=upload" class="w3-right" style="text-decoration: none"><button <?php if ($c == 0) { ?>class="btn" disabled <?php } else { ?> class="btn w3-hover-blue" <?php } ?>>Export Excel Upload Sistem</button></a>
    </div>
    <div class="container-fluid" style="margin-top: 10px">
        <a style="margin-right: 20px; text-decoration: none">Jumlah yang belum konfirmasi : <?php
            echo $nc . " / " . $s . " (";
            if ($nc == 0 || $s == 0) {
                echo "0.00%)";
            } else {
                echo number_format(($nc / $s) * 100, 2) . "%)";
            }
            ?>
        </a>
        <a href="controller/download.php?download=nc" class="w3-right" style="text-decoration: none">
            <button <?php if ($nc == 0) {
                ?>class="btn" disabled <?php
                } else {
                    ?> class="btn w3-hover-blue" <?php }
                ?>>
                Export Excel Belum Konfirmasi
            </button>
        </a>
    </div>
    <?php
    if (count($glitch) > 0) {
        ?>
        <div class="container-fluid" style="margin-top: 10px">
            Glitch = 
            <?php
            for ($x = 0; $x < count($glitch); $x++) {
                echo $glitch[$x];
                if ($x != count($glitch) - 1) {
                    echo ',';
                }
            }
            ?> | No. of glitch = <?php echo count($glitch); ?>
        </div>
        <?php
    }
    ?>
    <div class="container-fluid" style="margin-top: 10px">
        <div class="container-fluid">
            <h4 class="w3-center">
                <strong>
                    Download Kontak Peserta
                </strong>
            </h4>
        </div>
        <div class="container-fluid w3-center" style="overflow: auto">
            <table class="w3-center table" style="background-color: white; border: 1px; border-color: black; border-style: solid">
                <?php
                for ($x = 0; $x < $jumlah_sesi; $x++) {
                    ?>
                    <tr>
                        <td colspan="<?php echo $jumlah_proctor ?>">
                            Sesi <?php echo $x + 1 ?>
                        </td>
                    </tr>
                    <tr>
                        <?php
                        for ($y = 0; $y < $jumlah_proctor; $y++) {
                            ?>
                            <td>
                                <a style="margin: 10px; text-decoration: none" href="controller/download.php?download=proctor&no=<?php echo $y ?>&sesi=<?php echo $x ?>">
                                    <button <?php if ($mqc < $peserta_proctor * ($y + $jumlah_proctor * $x) + 1) { ?>disabled class="btn btn-warning"<?php } else { ?>class="btn btn-success"<?php } ?> >
                                        Proctor<br><?php echo $y + 1 ?>
                                    </button>
                                </a>
                                <br>
                                <?php
                                if ($mqc >= $peserta_proctor * (($y + 1) + $jumlah_proctor * $x)) {
                                    echo 'Complete';
                                } elseif ($mqc < $peserta_proctor * ($y + $jumlah_proctor * $x) + 1) {
                                    echo 'Not Available';
                                } else {
                                    echo 'In Progress';
                                }
                                ?>
                                <br>
                                <strong>
                                    <?php
                                    echo $counter[$y][$x];
                                    ?>
                                </strong>/
                                <?php
                                echo $peserta_proctor;
                                ?>
                                <br>
                                <?php
                                if (!($mqc < $peserta_proctor * ($y + $jumlah_proctor * $x) + 1)) {
                                    ?>
                                    <div class="w3-tiny w3-round w3-orange">

                                        <div class="w3-container w3-round w3-light-blue" style="width:<?php echo ($counter[$y][$x] / $peserta_proctor) * 100 ?>%;">
                                            <strong>
                                                <?php printf("%.2f", ($counter[$y][$x] / $peserta_proctor) * 100) ?>%
                                            </strong>
                                        </div>

                                    </div>
                                    <?php
                                }
                                ?>
                            </td>
                            <?php
                        }
                        ?>
                    </tr>
                    <?php
                }
                ?>

            </table>
        </div>
    </div>


    <?php
    include '../model/db_connection.php';
    $sql = "select * from akun_online_daftar_nama inner join akun_online on akun_online.id = akun_online_daftar_nama.id order by akun_online.id asc";
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        ?>
        <div class="w3-center container-fluid" style="overflow: auto; height: 500px; font-size: 9pt; margin-bottom: 50px">
            <table class="table table-responsive table-bordered table-striped" style="background-color: white;">
                <thead class="thead-dark">
                    <tr>
                        <th style="text-align: center; vertical-align: middle">No.</th>
                        <th style="text-align: center; vertical-align: middle">Antrian Konfirmasi</th>
                        <th style="text-align: center; vertical-align: middle">NIM</th>
                        <th style="text-align: center; vertical-align: middle">Nama</th>
                        <th style="text-align: center; vertical-align: middle">Fakultas</th>
                        <th style="text-align: center; vertical-align: middle">Status</th>
                        <th style="text-align: center; vertical-align: middle">Waktu Update</th>
                        <th style="text-align: center; vertical-align: middle">Konfirmasi</th>
                        <th style="text-align: center; vertical-align: middle">Waktu Konfirmasi</th>
                        <th style="text-align: center; vertical-align: middle">Proctor</th>
                        <th style="text-align: center; vertical-align: middle">Sesi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $c = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?> 

                        <tr>
                            <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                <?php
                                echo $c;
                                $c++;
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                <?php
                                if (intval($row["queue_confirm"]) > 0) {
                                    echo $row["queue_confirm"];
                                }
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                <?php
                                echo $row["nim"];
                                ?>
                            </td>
                            <td style="vertical-align : middle; text-align: left; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                <?php
                                echo $row["nama"];
                                ?>
                            </td>
                            <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                <?php
                                echo $row["fakultas"];
                                ?>
                            </td>
                            <?php
                            if (intval($row["confirmation"]) === 0 && intval($row["close"]) === 1) {
                                ?>
                            <td style="vertical-align : middle;text-align:center; cursor: pointer; color: white; background-color: #ff0000; " onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'" colspan="6">
                                Update Data Ditutup! (Tidak Update Data)
                            </td>
                                <?php
                            } else {
                                ?>                            
                                <td style="vertical-align : middle;text-align:center; cursor: pointer; <?php if ($row["status"] == 1) { ?>background-color: lime; <?php } else { ?> color: white; background-color: #ff0000; <?php } ?>" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    switch ($row["status"]) {
                                        case 1:
                                            echo 'Sudah Update Data';
                                            break;
                                        default:
                                            echo 'Belum Update Data';
                                            break;
                                    }
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    echo $row["time_update"];
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center; cursor: pointer; <?php if ($row["confirmation"] == 1) { ?>background-color: lime; <?php } else { ?> color: white; background-color: #ff880b; <?php } ?>" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    switch ($row["confirmation"]) {
                                        case 1:
                                            echo 'Data Terkonfirmasi';
                                            break;
                                        default:
                                            echo 'Data Belum Dikonfirmasi';
                                            break;
                                    }
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    echo $row["time_confirmation"];
                                    ?>
                                </td>
                                <?php
                                $sesi = ceil(intval($row["queue_confirm"]) * $jumlah_sesi / $jumlah_peserta);
                                $proctor = ceil(intval($row["queue_confirm"]) / $peserta_proctor) - $jumlah_proctor * ($sesi - 1);
                                ?>
                                <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    if ($sesi != '0') {
                                        echo $proctor;
                                    }
                                    ?>
                                </td>
                                <td style="vertical-align : middle;text-align:center; cursor: pointer" onclick="location.href = 'detail.php?id=<?php echo $row["id"] ?>'">
                                    <?php
                                    if ($sesi != 0) {
                                        echo $sesi;
                                    }
                                    ?>
                                </td>
                                <?php
                            }
                            ?>
                        </tr>                 
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    ?>

</body>