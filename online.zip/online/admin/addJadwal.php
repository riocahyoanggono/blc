<?php
session_start();
if (($_SESSION["akun_online"] != "admin") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    ?>
    <body>
        <div class="container w3-center">
            <form method="POST" action="controller/addJadwal.php">
                <div class="container" style="width: 25%">
                    Tanggal <input class="w3-right" style="width: 60%" type="date" name="tgl" required>
                </div>
                <div class="container" style="width: 25%; margin-top: 15px">
                    Waktu <input class="w3-right" style="width: 60%" type="time" name="waktu" required>
                </div>
                <div class="container">
                    <button type="submit" style="margin-top: 10px">Tambah Jadwal</button>
                </div>
            </form>
        </div>
    </body>
    <?php
}
