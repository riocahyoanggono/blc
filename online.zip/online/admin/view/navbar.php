<!DOCTYPE html>

<html lang="id">
    <head>
        <link rel="apple-touch-icon" sizes="57x57" href="../lib/fav/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../lib/fav/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../lib/fav/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../lib/fav/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../lib/fav/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../lib/fav/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../lib/fav/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../lib/fav/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../lib/fav/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../lib/fav/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../lib/fav/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../lib/fav/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../lib/fav/favicon-16x16.png">
        <link rel="manifest" href="../lib/fav/manifest.json">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src="https://www.w3schools.com/lib/w3.js"></script>
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <style>
            * {
                box-sizing: border-box;
            }

            /* Create two equal columns that floats next to each other */
            .column {
                float: left;
                width: 50%;
                padding: 10px;
                height: 150px; /* Should be removed. Only for demonstration */
            }

            /* Clear floats after the columns */

            /* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
            @media screen and (max-width: 600px) {
                .column {
                    width: 100%;
                }
            }
        </style>
        <title>TOEFL ITP | Admin</title>
    </head>
    <body>
        <script>
            function windowConfirm() {
                var choice = confirm("Apakah anda yakin ingin menghapus data Online");
                if (choice == true) {
                    window.location = 'controller/truncate.php';
                }
            }
            function closeUpdate() {
                var choice = confirm("Apakah anda yakin ingin menutup sistem update Peserta?");
                if (choice == true) {
                    window.location = 'controller/close.php';
                }
            }
        </script>
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li><a href="../admin/">Beranda</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Mahasiswa<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="uploadMhs.php">Upload Data Mahasiswa</a></li>
                                <li><a href="addMHS.php">Tambah Mahasiswa Baru</a></li>
                                <li><a href="viewPassword.php">Cek Password</a></li>
                            </ul>
                        </li>
                        <li><a href="#" onclick="closeUpdate()">Tutup Sistem Update</a></li>
<!--                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Jadwal<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="daftarJadwal.php">Lihat Daftar Jadwal</a></li>
                                <li><a href="addJadwal.php">Tambah Jadwal Tes</a></li>  
                            </ul>
                        </li>-->
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        include '../model/db_connection.php';
                        $sql = "select count(id) as i from akun_online_daftar_nama";
                        $result = mysqli_query($link, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            if ($row["i"] > 0) {
                                ?>
                                <li><a href="#" onclick="windowConfirm()">Kosongkan Table</a></li>
                                <?php
                            }
                        }
                        ?>
                        <li><a href="../logout/"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </body>
</html>