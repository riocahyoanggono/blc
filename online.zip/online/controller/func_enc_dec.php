<?php

function encode($s) {
    $re = str_split($s);
    $re3 = [];
    for ($i = 0; $i < count($re); $i++) {
        $re3[$i] = ord($re[$i]);
    }
    return implode(" ", $re3);
}

function decode($s) {
    $re = explode(" ", $s);
    for ($i = 0; $i < count($re); $i++) {
        $re7[$i] = chr($re[$i]);
    }
    return implode("", $re7);
}