<?php

$link = mysqli_connect('localhost', 'toeflrutin', 'ftqixpvaes', 'db_toeflrutin');
//$link = mysqli_connect('localhost', 'root', '', 'db_toeflrutin');
if(!$link) {
    echo 'Error';
}