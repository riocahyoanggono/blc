<?php

session_start();
if (!empty($_SESSION["akun_online"])) {
    unset($_SESSION["akun_online"]);
    header("location: ../");
} else {
    header("location: ../");
}