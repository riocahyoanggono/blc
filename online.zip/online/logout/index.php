<?php

session_start();
if (!empty($_SESSION["akun_online"])) {
    session_unset();
    header("location: ../");
} else {
    header("location: ../");
}