<?php
header("location: ../");
