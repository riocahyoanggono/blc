<?php

session_start();
if (!empty($_SESSION["user_online"])) {
    header("location: ./../");
} else {
    include './view/loginForm.php';
}