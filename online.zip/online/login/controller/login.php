<?php

session_start();
include '../../model/db_connection.php';
include '../../controller/func_enc_dec.php';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = mysqli_real_escape_string($link, encode($_POST["user"]));
    $password = mysqli_real_escape_string($link, encode($_POST["pass"]));
}
if (empty($username) || empty($password)) {
    echo "<script> window.location = '../';</script>";
}
$sql = "SELECT * FROM akun_online WHERE user = '$username' and pass = '$password'";
$query = mysqli_query($link, $sql);
if (mysqli_num_rows($query) > 0) {
    while ($row = mysqli_fetch_assoc($query)) {
        if ($row["id"] == 1) {
            $_SESSION["akun_online"] =  decode($username);
        } else {
            if ($row["close"] == 1) {
                $_session["closed"] = 1;
                echo "<script> window.location = '../../close.php';</script>";
            } else {
                $_SESSION["akun_online"] = "student";
                $_SESSION["akun_online_id"] = $row["id"];
            }
        }
        echo "<script> window.location = '../../';</script>";
        break;
    }
} else {
    echo "<script>alert('Username atau Password salah!!!'); history-go(-1);</script>";
    echo "<script> window.location = '../';</script>";
}

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
