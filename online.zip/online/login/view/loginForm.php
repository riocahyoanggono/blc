<!DOCTYPE html>
<html lang="id">
    <head>
        <title>TOEFL ITP | Login</title>
        <link rel="apple-touch-icon" sizes="57x57" href="../lib/fav/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../lib/fav/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../lib/fav/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../lib/fav/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../lib/fav/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../lib/fav/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../lib/fav/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../lib/fav/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../lib/fav/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../lib/fav/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../lib/fav/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../lib/fav/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../lib/fav/favicon-16x16.png">
        <link rel="manifest" href="../lib/fav/manifest.json">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../lib/login.css">
        <script src="../lib/login.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="login-container">
                <div id="output"></div>
                <!--<div class="avatar"></div>-->
                <h3><b>Login Page</b></h3>
                <div class="form-box">
                    <form action="<?php echo htmlspecialchars('controller/login.php'); ?>" method="POST">
                        <input name="user" type="text" placeholder="Username" required>
                        <input name="pass" type="password" placeholder="Password" required>
                        <button class="btn btn-info btn-block login" type="submit">Login</button>

                    </form>
                    <a href="http://toeflrutin.blc.ub.ac.id/hasiltes/" style="text-decoration: none"><button class="btn btn-success btn-block login">Hasil Tes Online</button></a>
                    <p align="center" style="padding-top: 2px;color: green; border-top-style: solid; border-top-color: white; border-top-width: 3px;">Update Data Online v1.5</p>
                    <p align="center" style="padding-top: 2px;color: green; border-top-style: solid; border-top-color: white; border-top-width: 3px;">&copy;BLC UB, <?php echo date("Y") ?></p>
                </div>
            </div>
        </div>
    </body>
</html>