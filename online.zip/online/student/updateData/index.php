<?php
session_start();
if(($_SESSION["akun_online"] != "student")||(empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    $sql = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
    $result = mysqli_query($link, $sql);
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            if($row["status"] == 0) {
                include './view/formUpdate.php';
            } else {
                header("location: ../");
            }
        }
    }
}

