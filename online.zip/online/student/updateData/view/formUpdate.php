<!DOCTYPE HTML>
<html lang="ID">

    <head>
        <!-- Required meta tags-->
        <link rel="apple-touch-icon" sizes="57x57" href="../../lib/fav/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../../lib/fav/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../../lib/fav/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../../lib/fav/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../../lib/fav/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../../lib/fav/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../../lib/fav/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../../lib/fav/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../../lib/fav/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="../../lib/fav/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../../lib/fav/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="../../lib/fav/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../../lib/fav/favicon-16x16.png">
        <link rel="manifest" href="../../lib/fav/manifest.json">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Colorlib Templates">
        <meta name="author" content="Colorlib">
        <meta name="keywords" content="Colorlib Templates">

        <!-- Title Page-->
        <title>Update Data</title>

        <!-- Icons font CSS-->
        <link href="view/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="view/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <!-- Font special for pages-->
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

        <!-- Vendor CSS-->
        <link href="view/vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="view/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

        <!-- Main CSS-->
        <link href="view/css/main.css" rel="stylesheet" media="all">
    </head>

    <body style="background-image: url(https://uploads.toptal.io/blog/image/123686/toptal-blog-image-1501178946393-ce513b02e7d488a192ed06a88c2f2759.png)">
        <div class="page-wrapper p-t-100 p-b-100 font-robo">
            <div class="wrapper wrapper--w680">
                <div class="card card-1">
                    <div class="card-heading"></div>
                    <div class="card-body">
                        <h3 class="title">
                            Silahkan update data anda terlebih dahulu!
                        </h3>
                        <h5 class="title2" style="color: red; font-style: italic;">
                            Pastikan data yang dimasukkan sesuai dengan data pribadi!<br>
                            <strong>Bacalah manual yang dikirim email sebelum update agar tidak terjadi kesalahan!</strong>
                            <br>
                        </h5>
                        <form method="POST" action="<?php echo htmlspecialchars('proses/'); ?>">
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-1" type="password" placeholder="PASSWORD BARU" name="new_pass" id="new_pw" required maxlength="20" autofocus>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-1" type="password" name="re_pass" placeholder="ULANGI PASSWORD BARU" id="re_new_pw" required maxlength="20">
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <?php
                                $val_nama = "";
                                $val_nim = "";

                                $sql4 = "select * from akun_online_daftar_nama where id = " . $_SESSION["akun_online_id"];
                                $result2 = mysqli_query($link, $sql4);
                                if (mysqli_num_rows($result2) > 0) {
                                    while ($row2 = mysqli_fetch_assoc($result2)) {
                                        $val_nama = strtoupper($row2["nama"]);
                                        $val_nim = $row2["nim"];
                                    }
                                }
                                ?>
                                <input class="input--style-1" type="text" value="<?php echo $val_nim; ?>" placeholder="NIM" name="nim" disabled="">
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-1" type="text" style="text-transform: uppercase" placeholder="NAMA DEPAN & NAMA TENGAH" name="nama" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-1" type="text" style="text-transform: uppercase" placeholder="NAMA BELAKANG" name="last_name" required autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <input class="input--style-1" type="text" style="text-transform: uppercase" placeholder="NAMA LENGKAP" name="full_name" required autocomplete="off">
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="fakultas" required>
                                                <option disabled selected value="">FAKULTAS</option>
                                                <option value="FH">FH</option>
                                                <option value="FEB">FEB</option>
                                                <option value="FIA">FIA</option>
                                                <option value="FP">FP</option>
                                                <option value="FAPET">FAPET</option>
                                                <option value="FMIPA">FMIPA</option>
                                                <option value="FT">FT</option>
                                                <option value="FTP">FTP</option>
                                                <option value="FPIK">FPIK</option>
                                                <option value="FISIP">FISIP</option>
                                                <option value="FK">FK</option>
                                                <option value="FKH">FKH</option>
                                                <option value="FKG">FKG</option>
                                                <option value="FIB">FIB</option>
                                                <option value="FILKOM">FILKOM</option>
                                                <option value="VOKASI">VOKASI</option>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="jenjang" required>
                                                <option disabled selected value="">JENJANG</option>
                                                <option value="D3">D3</option>
                                                <option value="S1">S1</option>
                                                <option value="S2">S2</option>
                                                <option value="S3">S3</option>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="tgl_lahir" required>
                                                <option disabled selected value="">TANGGAL LAHIR</option>
                                                <?php
                                                for ($i = 1; $i <= 31; $i++) {
                                                    ?>
                                                    <option value="<?php 
                                                    if($i<10) {
                                                        echo "0".$i;
                                                    } else {
                                                        echo $i;
                                                    }
                                                    ?>"><?php echo $i; ?></option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="bln_lahir" required>
                                                <option disabled selected value="">BULAN LAHIR</option>
                                                <?php
                                                for ($i = 1; $i <= 12; $i++) {
                                                    ?>
                                                    <option value="<?php
                                                    if($i<10) {
                                                        echo "0".$i;
                                                    } else {
                                                        echo $i;
                                                    }
                                                    ?>">
                                                        <?php
                                                        $dateObj = DateTime::createFromFormat('!m', $i);
                                                        $monthName = strtoupper($dateObj->format('F'));
                                                        echo $monthName;
                                                        ?>
                                                    </option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple">
                                            <select name="thn_lahir" required>
                                                <option disabled selected value="">TAHUN LAHIR</option>
                                                <?php
                                                for ($i = date("Y") - 120; $i <= date("Y"); $i++) {
                                                    ?>
                                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="gender" required>
                                                <option disabled selected value="">JENIS KELAMIN</option>
                                                <option value="M">PRIA</option>
                                                <option value="F">WANITA</option>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <input class="input--style-1" type="email" placeholder="EMAIL AKTIF" name="email" required autocomplete="off">
                            </div>
                            <div class="input-group">
                                <input class="input--style-1" type="text" placeholder="NO. HP AKTIF" name="hp" maxlength="15" required autocomplete="off">
                            </div>
                            <div class="input-group">
                                <input class="input--style-1" type="text" placeholder="NO. WHATSAPP AKTIF" name="wa" maxlength="15" required autocomplete="off">
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple">
                                            <select name="nat_country" required>
                                                <option value="" disabled selected>KEBANGSAAN</option>
                                                <?php
                                                $sql5 = "select * from nat_country_list";
                                                $result5 = mysqli_query($link, $sql5);
                                                if (mysqli_num_rows($result5) > 0) {
                                                    while ($row5 = mysqli_fetch_assoc($result5)) {
                                                        ?><option value="<?php echo $row5["id"] ?>"><?php echo $row5["country"] ?></option> <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple">
                                            <select name="nat_language" required>
                                                <option value="" disabled selected>BAHASA ASLI</option>
                                                <?php
                                                $sql5 = "select * from nat_language_list";
                                                $result5 = mysqli_query($link, $sql5);
                                                if (mysqli_num_rows($result5) > 0) {
                                                    while ($row5 = mysqli_fetch_assoc($result5)) {
                                                        ?><option value="<?php echo $row5["id"] ?>"><?php echo $row5["language"] ?></option> <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="p-t-20">
                                <button class="btn btn--radius btn--green" type="submit" onclick="return validatePassword()" style="margin-right: 20px">Simpan</button>
                                <a style="text-decoration: none; float: right" class="btn btn--radius btn--red" href="../../logout/">Logout</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Jquery JS-->
        <script src="view/vendor/jquery/jquery.min.js"></script>
        <!-- Vendor JS-->
        <script src="view/vendor/select2/select2.min.js"></script>
        <script src="view/vendor/datepicker/moment.min.js"></script>
        <script src="view/vendor/datepicker/daterangepicker.js"></script>

        <!-- Main JS-->
        <script src="view/js/global.js"></script>
        <script>
                                    function validatePassword() {
                                        var pass = document.getElementById("new_pw").value;
                                        var re_pass = document.getElementById("re_new_pw").value;
                                        if (pass != re_pass) {
                                            alert("Password baru tidak sama.");
                                            return false;
                                        } else {
                                            return true;
                                        }
                                    }
        </script>

    </body>

</html>