<?php

session_start();
include '../../../model/db_connection.php';
date_default_timezone_set("Asia/Jakarta");

function encode($s) {
    $re = str_split($s);
    $re3 = [];
    for ($i = 0; $i < count($re); $i++) {
        $re3[$i] = ord($re[$i]);
    }
    return implode(" ", $re3);
}

function decode($s) {
    $re = explode(" ", $s);
    for ($i = 0; $i < count($re); $i++) {
        $re7[$i] = chr($re[$i]);
    }
    return implode("", $re7);
}

function clear($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (empty($_POST["nim"])) {
    echo "<script> window.location = '../';</script>";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $country = $language = "";
    if (encode(clear($_POST["new_pass"])) != encode(clear($_POST["re_pass"]))) {
        echo "<script>alert('Password Tidak Sama!!'); history-go(-1);</script>";
        echo "<script> window.location = '../';</script>";
    } else {
        $password = encode(clear($_POST["new_pass"]));
        $nama = strtoupper(clear($_POST["nama"]));
        $last_nama = strtoupper(clear($_POST["last_name"]));
        $full_name = strtoupper(clear($_POST["full_name"]));
        $fakultas = clear($_POST["fakultas"]);
        $hp = clear($_POST["hp"]);
        $wa = clear($_POST["wa"]);
        $email = clear($_POST["email"]);
        $gender = clear($_POST["gender"]);
        $jenjang = clear($_POST["jenjang"]);
        $tgl_lahir = clear($_POST["tgl_lahir"]);
        $bln_lahir = clear($_POST["bln_lahir"]);
        $thn_lahir = clear($_POST["thn_lahir"]);
        $sql6 = "select * FROM nat_country_list WHERE id = " . clear($_POST["nat_country"]);
        $result6 = mysqli_query($link, $sql6);
        if (mysqli_num_rows($result6) > 0) {
            while ($row = mysqli_fetch_array($result6)) {
                $country = $row["country"];
                $country_code = $row["country_code"];
            }
        }
        $sql7 = "select * FROM nat_language_list WHERE id = " . clear($_POST["nat_language"]);
        $result7 = mysqli_query($link, $sql7);
        if (mysqli_num_rows($result7) > 0) {
            while ($row = mysqli_fetch_array($result7)) {
                $language = $row["language"];
                $language_code = $row["language_code"];
            }
        }

        if (empty($nama) || empty($fakultas) || empty($email) || empty($hp) || empty($wa) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('DATA TIDAK TERSIMPAN! Periksa kembali data anda!'); history-go(-1);</script>";
            echo "<script> window.location = '../';</script>";
        } else {

            $sql2 = "update akun_online_daftar_nama "
                    . "set nama = '$full_name', "
                    . "first_name = '$nama', "
                    . "last_name = '" . $last_nama . "', "
                    . "fakultas = '$fakultas', "
                    . "hp = '$hp', "
                    . "wa = '$wa', "
                    . "email = '$email', "
                    . "tgl_lahir = '" . $tgl_lahir . "', "
                    . "bln_lahir = '" . $bln_lahir . "', "
                    . "thn_lahir = '" . $thn_lahir . "', "
                    . "gender = '$gender', "
                    . "nat_country = '$country', "
                    . "nat_language = '$language', "
                    . "country_code = '$country_code', "
                    . "language_code = '$language_code', "
                    . "jenjang = '$jenjang' "
                    . "where id = " . $_SESSION["akun_online_id"] . ";";

            if (mysqli_query($link, $sql2)) {
                $sql31 = "update akun_online set pass = '" . $password . "', status = '1', time_update = '" . date('d-m-Y') . " " . date("H:i:s") . "' where id = " . $_SESSION["akun_online_id"];
                if (mysqli_query($link, $sql31)) {
                    echo "<script>alert('DATA TIDAK TERSIMPAN. "
                    . "Tidak diperkenankan untuk menggunakan karakter selain Nomor, Huruf, Tanda @ (at), Tanda . (titik),  dan Spasi. Jika terdapat tanda petik satu, dapat diganti dengan Spasi!'); history-go(-1);</script>";
                    echo "<script>window.location = '../../';</script>";
                }
            } else {
                echo "<script>alert('DATA TIDAK TERSIMPAN. "
                . "Tidak diperkenankan untuk menggunakan karakter selain Nomor, Huruf, Tanda @ (at), Tanda . (titik),  dan Spasi. Jika terdapat tanda petik satu, dapat diganti dengan Spasi!'); history-go(-1);</script>";
                echo "<script> window.location = '../';</script>";
            }
        }
    }
}