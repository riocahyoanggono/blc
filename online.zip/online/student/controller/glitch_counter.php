<!DOCTYPE html>
<?php

function getGlitch($link) {
    $sql = "select * from akun_online where queue_confirm != 0 order by queue_confirm";
    $result = mysqli_query($link, $sql);

    $array = $problems = array();

    while ($row = mysqli_fetch_assoc($result)) {
        array_push($array, $row["queue_confirm"]);
    }

    $max_array = count($array);
    $j = 1;
    for ($i = 0; $i < $max_array; $i++) {
        if ($j != $array[$i]) {
            for ($x = $j; $x < $array[$i]; $x++) {
                array_push($problems, $x);
                $j++;
            }
        }
        $j++;
    }
    return $problems;
}
