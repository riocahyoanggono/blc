<?php

session_start();

function encode($s) {
    $re = str_split($s);
    $re3 = [];
    for ($i = 0; $i < count($re); $i++) {
        $re3[$i] = ord($re[$i]);
    }
    return implode(" ", $re3);
}

function decode($s) {
    $re = explode(" ", $s);
    for ($i = 0; $i < count($re); $i++) {
        $re7[$i] = chr($re[$i]);
    }
    return implode("", $re7);
}

if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    if (empty($_POST["current_pw"]) || empty($_POST["new_pw"])) {
        ?>
        <script>
            window.location = '../';
        </script>
        <?php
    }
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $old_pw = encode(mysqli_real_escape_string($link, $_POST["current_pw"]));
        $new_pw = encode(mysqli_real_escape_string($link, $_POST["new_pw"]));
        $sql = "select * FROM akun_online where id = " . $_SESSION["akun_online_id"];
        $result = mysqli_query($link, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                if ($row["pass"] == $old_pw) {
                    $sql2 = "update akun_online set pass = '$new_pw' where id = " . $_SESSION["akun_online_id"];
                    mysqli_query($link, $sql2);
                    ?>
                    <script>
                        window.alert("Password diganti.");
                        window.location = '../../student/';
                    </script>
                    <?php

                } else {
                    ?>
                    <script>
                        window.alert("Password lama Salah.");
                        window.location = '../../student/gantiPassword.php';
                    </script>
                    <?php

                }
            }
        }
    }
}