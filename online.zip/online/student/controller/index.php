<?php

header("location:../");