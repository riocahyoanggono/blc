<?php

session_start();

function clear($data) {
    return trim(stripslashes(htmlspecialchars($data)));
}

if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../../model/db_connection.php';
    
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $first_name = strtoupper(clear($_POST["first_name"]));
        $last_name = strtoupper(clear($_POST["last_name"]));
        $full_name = strtoupper(clear($_POST["full_name"]));
        $fakultas = clear($_POST["fakultas"]);
        $jenjang = clear($_POST["jenjang"]);
        $tgl_lahir = clear($_POST["tgl_lahir"]);
        $bln_lahir = clear($_POST["bln_lahir"]);
        $thn_lahir = clear($_POST["thn_lahir"]);
        $gender = $_POST["gender"];
        $email = clear($_POST["email"]);
        $hp = clear($_POST["hp"]);
        $wa = clear($_POST["wa"]);
        $sql6 = "select * FROM nat_country_list WHERE id = " . clear($_POST["nat_country"]);
        $result6 = mysqli_query($link, $sql6);
        if (mysqli_num_rows($result6) > 0) {
            while ($row = mysqli_fetch_array($result6)) {
                $country = $row["country"];
                $country_code = $row["country_code"];
            }
        }
        $sql7 = "select * FROM nat_language_list WHERE id = " . clear($_POST["nat_language"]);
        $result7 = mysqli_query($link, $sql7);
        if (mysqli_num_rows($result7) > 0) {
            while ($row = mysqli_fetch_array($result7)) {
                $language = $row["language"];
                $language_code = $row["language_code"];
            }
        }
    }
    if (empty($first_name) || empty($last_name) || empty($fakultas) || empty($email) || empty($hp) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script> window.alert('DATA TIDAK TERSIMPAN! Periksa kembali data anda!'); history-go(-1);</script>";
        echo "<script> window.location = '../ubahData.php';</script>";
    } else {
        $sql2 = "update akun_online_daftar_nama "
                . "set nama = '$full_name', "
                . "first_name = '$first_name', "
                . "last_name = '$last_name', "
                . "fakultas = '$fakultas', "
                . "jenjang = '$jenjang', "
                . "hp = '$hp', "
                . "wa = '$wa', "
                . "email = '$email', "
                . "tgl_lahir = '$tgl_lahir', "
                . "bln_lahir = '$bln_lahir', "
                . "thn_lahir = '$thn_lahir', "
                . "gender = '$gender', "
                . "nat_country = '$country', "
                . "nat_language = '$language', "
                . "country_code = '$country_code', "
                . "language_code = '$language_code' "
                . "where id = " . $_SESSION["akun_online_id"] . ";";
        mysqli_query($link, $sql2);
        header("location:../");
    }
}