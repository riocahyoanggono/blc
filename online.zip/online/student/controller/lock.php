<!DOCTYPE html>
<?php
session_start();

if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    date_default_timezone_set('Asia/Jakarta');
    include '../../model/db_connection.php';
    $sql2 = "SELECT MAX(queue_confirm) as q from akun_online";
    $result2 = mysqli_query($link, $sql2);
    $q = 0;
    while ($row = mysqli_fetch_assoc($result2)) {
        $q = $row["q"] + 1;
    }
    $sql = "update akun_online set confirmation = 1, time_confirmation = '" . date('d-m-Y') . " " . date('H:i:s') . "', queue_confirm = $q where id = " . $_SESSION["akun_online_id"];
    $result = mysqli_query($link, $sql);

    echo "<script> window.location = '../../';</script>";
}
