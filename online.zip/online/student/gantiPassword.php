<!DOCTYPE HTML>
<?php
session_start();

if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    ?>
    <body>
        <script>
            function validatePassword() {
                var pass = document.getElementById("new_pw").value;
                var re_pass = document.getElementById("re_new_pw").value;
                if (pass != re_pass) {
                    alert("Password baru tidak sama.");
                    return false;
                } else {
                    return true;
                }
            }
        </script>
        <div class="container" style="margin-top: 70px">
            <h2 class="w3-center">
                <strong>
                    Ganti Password
                </strong>
            </h2>
        </div>
        <div class="container" style="margin-top: 20px">
            <form action="controller/gantiPassword.php" method="POST">
                <div class="row">
                    <div class="container" style="width: 50%">
                        Password Saat Ini <input name="current_pw" type="password" class="w3-right" style="width: 55%" required>
                    </div>
                    <div class="container" style="width: 50%; margin-top: 15px">
                        Password Baru <input name="new_pw" type="password" id="new_pw" class="w3-right" style="width: 55%" required>
                    </div>
                    <div class="container" style="width: 50%; margin-top: 15px">
                        Ulangi Password Baru <input name="re_new_pw" id="re_new_pw" type="password" class="w3-right" style="width: 55%" required>
                    </div>
                    <div class="container w3-center" style="width: 50%; margin-top: 20px">
                        <button type="submit" onclick="return validatePassword()" style="margin-right: 50px" class="w3-button w3-blue w3-round-large w3-hover-cyan">
                            Ubah
                        </button>
                        <a href="../student/" style="text-decoration: none" class="w3-button w3-pink w3-round-large w3-hover-red">
                            Batal
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </body>
    <?php
}