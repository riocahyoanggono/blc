<?php
session_start();
if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include './view/navbar.php';
    include '../model/db_connection.php';
    $sql = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($row["confirmation"] == 1) {
                header("location: ../");
            }
        }
    }
    $sql2 = "select * from akun_online_daftar_nama where id = " . $_SESSION["akun_online_id"];
    $result2 = mysqli_query($link, $sql2);
    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
            ?>
            <body>
                <form action="controller/prosesUbah.php" method="POST">
                    <div class="container-fluid" style="margin-top: 70px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            NIM
                        </div>
                        <div class="col-sm-4">
                            <input name="nim" type="text" disabled="" style="width:100%" value="<?php echo $row["nim"]; ?>">
                        </div>
                    </div>
                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Nama Depan dan Tengah
                        </div>
                        <div class="col-sm-4">
                            <input name="first_name" type="text" style="width:100%" value="<?php echo $row["first_name"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Nama Belakang
                        </div>
                        <div class="col-sm-4">
                            <input name="last_name" type="text" style="width:100%" value="<?php echo $row["last_name"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Nama Lengkap
                        </div>
                        <div class="col-sm-4">
                            <input name="full_name" type="text" style="width:100%" value="<?php echo $row["nama"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Fakultas
                        </div>
                        <div class="col-sm-4">
                            <select name="fakultas" style="height: 28px; width:100%" required>
                                <?php
                                $sql7 = "select * from online_settings";
                                $result7 = mysqli_query($link, $sql7);
                                while ($row7 = mysqli_fetch_assoc($result7)) {
                                    if (intval($row7["rutin"]) === 1) {
                                        $sql3 = "select * from daftar_fakultas where not urutan = 17 order by urutan asc";
                                    } elseif (intval($row7["rutin"]) === 2) {
                                        $sql3 = "select * from daftar_fakultas where urutan = 17";
                                    }
                                    $result3 = mysqli_query($link, $sql3);
                                    if (mysqli_num_rows($result3) > 0) {
                                        while ($row2 = mysqli_fetch_assoc($result3)) {
                                            ?>
                                            <option value="<?php echo $row2["singkatan"] ?>" <?php if ($row2["singkatan"] == $row["fakultas"]) { ?>selected<?php } ?>>
                                                <?php echo $row2["singkatan"] ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Jenjang
                        </div>
                        <div class="col-sm-4">
                            <select name="jenjang" required style="height: 28px; width:100%">
                                <option value="D3" <?php if ($row["jenjang"] == "D3") { ?>selected<?php } ?>>
                                    D3
                                </option>
                                <option value="S1" <?php if ($row["jenjang"] == "S1") { ?>selected<?php } ?>>
                                    S1
                                </option>
                                <option value="S2" <?php if ($row["jenjang"] == "S2") { ?>selected<?php } ?>>
                                    S2
                                </option>
                                <option value="S3" <?php if ($row["jenjang"] == "S3") { ?>selected<?php } ?>>
                                    S3
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px; width:100%">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Tanggal Lahir
                        </div>
                        <div class="col-sm-4">
                            <select name="tgl_lahir" style="width: 100%; height: 28px" required>
                                <?php
                                for ($i = 1; $i <= 31; $i++) {
                                    ?>
                                    <option value="<?php
                                    if ($i < 10) {
                                        echo "0" . $i;
                                    } else {
                                        echo $i;
                                    }
                                    ?>"<?php
                                            if (intval($row["tgl_lahir"]) === $i) {
                                                ?>
                                                selected
                                                <?php
                                            }
                                            ?>><?php echo $i; ?>
                                    </option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px; width:100%">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Bulan Lahir
                        </div>
                        <div class="col-sm-4">
                            <select name="bln_lahir" style="width: 100%; height: 28px" required>
                                <?php
                                for ($i = 1; $i <= 12; $i++) {
                                    ?>
                                    <option value="<?php
                                    if ($i < 10) {
                                        echo "0" . $i;
                                    } else {
                                        echo $i;
                                    }
                                    ?>"<?php
                                            if (intval($row["bln_lahir"]) === $i) {
                                                ?>
                                                selected
                                                <?php
                                            }
                                            ?>><?php echo $i; ?>
                                    </option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Tahun Lahir
                        </div>
                        <div class="col-sm-4">
                            <input type="text" name="thn_lahir" style="width: 100%" value="<?php echo $row["thn_lahir"] ?>" required>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Jenis Kelamin
                        </div>
                        <div class="col-sm-4">
                            <select name="gender" class="w3-right" style="width: 100%;" required>
                                <option value="M" <?php if ($row["gender"] === "M") { ?>selected<?php } ?>>PRIA</option>
                                <option value="F" <?php if ($row["gender"] === "F") { ?>selected<?php } ?>>WANITA</option>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Email
                        </div>
                        <div class="col-sm-4">
                            <input name="email" type="text" style="width: 100%" value="<?php echo $row["email"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            No. HP
                        </div>
                        <div class="col-sm-4">
                            <input name="hp" type="text" style="width:100%" value="<?php echo $row["hp"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px;">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            No. WA
                        </div>
                        <div class="col-sm-4">
                            <input name="wa" type="text" style="width:100%" value="<?php echo $row["wa"]; ?>">
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Kebangsaan
                        </div>
                        <div class="col-sm-4">
                            <select name="nat_country" style="width: 100%; height: 28px">
                                <?php
                                $sql5 = "SELECT * FROM akun_online_daftar_nama where id = " . $_SESSION["akun_online_id"];
                                $result5 = mysqli_query($link, $sql5);
                                if (mysqli_num_rows($result5) > 0) {
                                    while ($row3 = mysqli_fetch_array($result5)) {
                                        $countrySelection = $row3["nat_country"];
                                        $languageSelection = $row3["nat_language"];
                                    }
                                }
                                $sql4 = "select * FROM nat_country_list";
                                $result4 = mysqli_query($link, $sql4);
                                if (mysqli_num_rows($result4) > 0) {
                                    while ($row1 = mysqli_fetch_array($result4)) {
                                        ?>
                                        <option value="<?php echo $row1["id"] ?>" <?php if ($row1["country"] == $countrySelection) { ?>selected<?php } ?>><?php echo $row1["country"] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px; height: 28px">
                        <div class="col-sm-3">

                        </div>
                        <div class="col-sm-3">
                            Bahasa Asli
                        </div>
                        <div class="col-sm-4">
                            <select name="nat_language" class="w3-right" style="width: 100%; height: 28px; margin-bottom: 5px">
                                <?php
                                $sql6 = "select * FROM nat_language_list";
                                $result6 = mysqli_query($link, $sql6);
                                if (mysqli_num_rows($result6) > 0) {
                                    while ($row1 = mysqli_fetch_array($result6)) {
                                        ?>
                                        <option value="<?php echo $row1["id"] ?>" <?php if ($row1["language"] == $languageSelection) { ?>selected<?php } ?>><?php echo $row1["language"] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="container-fluid" style="margin-top: 10px; margin-bottom: 5px">
                        <div class="col-sm-4">

                        </div>
                        <div class="col-sm-2" style="text-align: center; margin-bottom: 5px">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
                        <div class="col-sm-2" style="text-align: center; margin-bottom: 5px">
                            <a class="btn btn-warning" href='./'>
                                Batalkan
                            </a>
                        </div>
                    </div>
                </form>
            </body>
            <?php
        }
    }
}    