<?php
session_start();
if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './controller/glitch_counter.php';
    $glitch = getGlitch($link);
    $sql = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($row["status"] == 0) {
                header("location: updateData/");
            }
        }
    }
    $sql4 = "select *, left(tgl_tes, 2) as tgl, mid(tgl_tes, 4,2) as bln, right(tgl_tes, 4) as thn from online_settings";
    $result4 = mysqli_query($link, $sql4);
    while ($row = mysqli_fetch_assoc($result4)) {
        $jumlah_peserta = intval($row["jumlah_peserta"]);
        $jumlah_proctor = intval($row["jumlah_proctor"]);
        $jumlah_sesi = intval($row["jumlah_sesi"]);
        $peserta_proctor = intval($row["peserta_proctor"]);
        $tgl = intval($row["tgl"]);
        $bln = intval($row["bln"]);
        $thn = intval($row["thn"]);
    }
    include './view/navbar.php';
    $sql2 = "select * from akun_online_daftar_nama inner join akun_online on akun_online_daftar_nama.id = akun_online.id where akun_online_daftar_nama.id = " . $_SESSION["akun_online_id"];
    $result2 = mysqli_query($link, $sql2);
    ?>
    <body>

        <?php
        if (mysqli_num_rows($result2) > 0) {
            while ($row = mysqli_fetch_assoc($result2)) {
                $no_urut = $row["queue_confirm"];
                ?>
                <div class="container-fluid" style="margin-top: 70px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        NIM
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["nim"]; ?>">
                    </div>
                </div>
                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Nama Depan dan Tengah
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["first_name"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Nama Belakang
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["last_name"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Nama Lengkap
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["nama"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Fakultas
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["fakultas"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Jenjang
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["jenjang"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Tanggal Lahir
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["tgl_lahir"] . "/" . $row["bln_lahir"] . "/" . $row["thn_lahir"] ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Jenis Kelamin
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php
                        if ($row["gender"] == "M") {
                            echo "PRIA";
                        } else {
                            echo 'WANITA';
                        }
                        ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Email
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width: 100%" value="<?php echo $row["email"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        No. HP
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["hp"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        No. WA
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["wa"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Kebangsaan
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["nat_country"]; ?>">
                    </div>
                </div>

                <div class="container-fluid" style="margin-top: 10px;">
                    <div class="col-sm-3">

                    </div>
                    <div class="col-sm-3">
                        Bahasa Asli
                    </div>
                    <div class="col-sm-4">
                        <input type="text" disabled="" style="width:100%" value="<?php echo $row["nat_language"]; ?>">
                    </div>
                </div>
                <?php
            }
        }
        ?>

        <?php
        $sql3 = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
        $result3 = mysqli_query($link, $sql3);
        if (mysqli_num_rows($result3) > 0) {
            while ($row = mysqli_fetch_assoc($result3)) {
                if ($row["confirmation"] == 0) {
                    ?>
                    <div class="container-fluid w3-center" style="margin-top: 8px; margin-bottom: 5px">
                        <a style="text-decoration: none; margin-right: 25px" href="ubahData.php">
                            <button class="w3-button w3-round-large w3-yellow w3-hover-orange">
                                Ubah Data
                            </button>
                        </a>
                        <button onclick="windowConfirm()" class="w3-button w3-round-large w3-aqua w3-hover-blue">
                            Konfirmasi Data
                        </button>
                    </div>
                    <?php
                } else {
                    ?>
<!--                    <script>
                        window.alert('Periksa bagian bawah laman beranda untuk melihat Proctor dan Sesi.')
                    </script>-->
                    <div class="container-fluid w3-center">
                        <hr style="height: 2px; color: gray; background-color: gray;">
                        <h4 class="w3-center" style="color: #ff6633;">
                            <strong>
                                <!--Data sudah dikonfirmasi.<br>
                                Anda akan dimasukkan/diundang kegrup khusus proctor<br>
                                oleh pihak BLC (Proctor) --><?php
//                               $sesi = ceil($no_urut * $jumlah_sesi / $jumlah_peserta);
//                              $proctor = ceil($no_urut / $peserta_proctor) - $jumlah_proctor * ($sesi - 1);
//                              if ($no_urut > $jumlah_peserta) {
//                                  $proctor = 7;
//                                  $sesi = 2;
//                               }
//                               echo $proctor . " Sesi " . $sesi;
                           ?><!--)<br>terkait langkah selanjutnya.<br> -->
                                <!--Sesi <?php // echo $sesi; ?> dilaksanakan pukul --> <?php
//                             if (intval($sesi) === 1) {
//                                 if (intval(date("w", mktime(0, 0, 0, $bln, $tgl, $thn))) === 5) {
//                                     echo "08.00";
//                                  } else {
//                                      echo "08.00";
//                                  }
//                               } else {
//                                  echo "13.00";
//                                }
                                ?> <!--WIB.-->
                                Data sudah dikonfirmasi. Anda akan dimasukkan/diundang kegrup khusus proctor oleh pihak blc terkait langkah selanjutnya.
                                
                            </strong>
                        </h4>
                    </div>
                    <?php
                }
            }
        }
        ?>

        <script>
            function windowConfirm() {
                var choice = confirm("Apakah anda yakin data sudah benar?\nANDA TIDAK DAPAT MERUBAH DATA SETELAH KONFIRMASI DATA!");
                if (choice === true) {
                    window.location = 'controller/lock.php';
                }
            }
        </script>
    </body>
    <?php
}