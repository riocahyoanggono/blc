<?php
session_start();
if (($_SESSION["akun_online"] != "student") || (empty($_SESSION["akun_online"]))) {
    header("location: ../");
} else {
    include '../model/db_connection.php';
    include './controller/glitch_counter.php';
    $sql = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($row["status"] == 0) {
                header("location: updateData/");
            }
        }
    }
    include './view/navbar.php';
    $sql2 = "select * from akun_online_daftar_nama inner join akun_online on akun_online_daftar_nama.id = akun_online.id where akun_online_daftar_nama.id = " . $_SESSION["akun_online_id"];
    $result2 = mysqli_query($link, $sql2);
    ?>
    <body>
        <div class="container" style="margin-top: 70px; overflow-x: auto; vertical-align: middle">
            <?php
            if (mysqli_num_rows($result2) > 0) {
                while ($row = mysqli_fetch_assoc($result2)) {
                    $no_urut = $row["queue_confirm"];
                    ?>
                    <div class="row">
                        <div class="container" style="width: 50%">
                            NIM <input type="text" disabled="" class="w3-right" style="width: 55%;" value="<?php echo $row["nim"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Nama Depan dan Tengah <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["first_name"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Nama Belakang <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["last_name"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Nama Lengkap <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["nama"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Fakultas <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["fakultas"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Jenjang <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["jenjang"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Tanggal Lahir <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["tgl_lahir"] . "/" . $row["bln_lahir"] . "/" . $row["thn_lahir"] ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Jenis Kelamin <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php if ($row["gender"] == "M") {
                echo "PRIA";
            } else {
                echo 'WANITA';
            } ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Email <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["email"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            No. HP <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["hp"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            No. WA <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["wa"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Kebangsaan <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["nat_country"]; ?>">
                        </div>
                    </div>
                    <div class="row" style="margin-top: 15px">
                        <div class="container" style="width: 50%">
                            Bahasa Asli <input type="text" disabled="" class="w3-right" style="width: 55%" value="<?php echo $row["nat_language"]; ?>">
                        </div>
                    </div>
                <?php
            }
        }
        ?>
        </div>
        <?php
        $sql3 = "select * from akun_online where id = " . $_SESSION["akun_online_id"];
        $result3 = mysqli_query($link, $sql3);
        if (mysqli_num_rows($result3) > 0) {
            while ($row = mysqli_fetch_assoc($result3)) {
                if ($row["confirmation"] == 0) {
                    ?>
                    <div class="container w3-center" style="margin-top: 15px">
                        <a style="text-decoration: none; margin-right: 25px" href="ubahData.php">
                            <button class="w3-button w3-round-large w3-yellow w3-hover-orange">
                                Ubah Data
                            </button>
                        </a>
                        <button onclick="windowConfirm()" class="w3-button w3-round-large w3-aqua w3-hover-blue">
                            Konfirmasi Data
                        </button>
                    </div>
                <?php
            } else {
                ?>
                    <div class="container w3-center" style="width: 50%">
                        <hr style="height:2px;color:gray;background-color:gray;width: auto;">
                        <h4 class="w3-center" style="color: #ff6633;">
                            <strong>
                                Data sudah dikonfirmasi.<br>
                                Anda akan dihubungi oleh pihak BLC (Proctor <?php
                                if ($no_urut < 31) {
                                    echo "1 Sesi 1";
                                } elseif ($no_urut >= 31 && $no_urut < 61) {
                                    echo "2 Sesi 1";
                                } elseif ($no_urut >= 61 && $no_urut < 91) {
                                    echo "3 Sesi 1";
                                } elseif ($no_urut >= 91 && $no_urut < 121) {
                                    echo "4 Sesi 1";
                                } elseif ($no_urut >= 121 && $no_urut < 151) {
                                    echo "5 Sesi 1";
                                } elseif ($no_urut >= 151 && $no_urut < 181) {
                                    echo "6 Sesi 1";
                                } elseif ($no_urut >= 181 && $no_urut < 211) {
                                    echo "7 Sesi 1";
                                } elseif ($no_urut >= 211 && $no_urut < 241) {
                                    echo "1 Sesi 2";
                                } elseif ($no_urut >= 241 && $no_urut < 271) {
                                    echo "2 Sesi 2";
                                } elseif ($no_urut >= 271 && $no_urut < 301) {
                                    echo "3 Sesi 2";
                                } elseif ($no_urut >= 301 && $no_urut < 331) {
                                    echo "4 Sesi 2";
                                } elseif ($no_urut >= 331 && $no_urut < 361) {
                                    echo "5 Sesi 2";
                                } elseif ($no_urut >= 361 && $no_urut < 391) {
                                    echo "6 Sesi 2";
                                } elseif ($no_urut >= 391 && $no_urut < 421) {
                                    echo "7 Sesi 2";
                                } else {
                                    $glitch = getGlitch($link);
                                    if ($glitch[$no_urut-420] < 31) {
                                        echo "1 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 31 && $glitch[$no_urut-420] < 61) {
                                        echo "2 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 61 && $glitch[$no_urut-420] < 91) {
                                        echo "3 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 91 && $glitch[$no_urut-420] < 121) {
                                        echo "4 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 121 && $glitch[$no_urut-420] < 151) {
                                        echo "5 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 151 && $glitch[$no_urut-420] < 181) {
                                        echo "6 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 181 && $glitch[$no_urut-420] < 211) {
                                        echo "7 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 211 && $glitch[$no_urut-420] < 241) {
                                        echo "1 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 241 && $glitch[$no_urut-420] < 271) {
                                        echo "2 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 271 && $glitch[$no_urut-420] < 301) {
                                        echo "3 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 301 && $glitch[$no_urut-420] < 331) {
                                        echo "4 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 331 && $glitch[$no_urut-420] < 361) {
                                        echo "5 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 361 && $glitch[$no_urut-420] < 391) {
                                        echo "6 Sesi 2";
                                    } elseif ($glitch[$no_urut-420] >= 391 && $glitch[$no_urut-420] < 421) {
                                        echo "7 Sesi 2";
                                    }
                                }
                                ?>)<br>terkait langkah selanjutnya.<br>
                            </strong>
                        </h4>
                    </div>
                    <?php
                }
            }
        }
        ?>

        <script>
            function windowConfirm() {
                var choice = confirm("Apakah anda yakin data sudah benar?\nANDA TIDAK DAPAT MERUBAH DATA SETELAH KONFIRMASI DATA!");
                if (choice === true) {
                    window.location = 'controller/lock.php';
                }
            }
        </script>
    </body>
    <?php
}